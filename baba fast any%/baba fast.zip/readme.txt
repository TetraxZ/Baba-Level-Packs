Put editor_menudata.lua into install location/Data/Editor (this file only works on versions past H because of the UTF format, but if you want to use this on G updates then look at steam guides and paste that)
Put baba fast into install location/Data/Worlds
you always start at 00 and this skips all overworld