Put the world into your install location/Data/Worlds

This pack only works on more recent versions of baba because of IDLE