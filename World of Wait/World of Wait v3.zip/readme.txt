Put the world into your install location/Data/Worlds

only works on more recent baba versions that support IDLE