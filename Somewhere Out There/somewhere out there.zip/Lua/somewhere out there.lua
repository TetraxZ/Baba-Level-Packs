function code(alreadyrun_)
	local playrulesound = false
	local alreadyrun = alreadyrun_ or false
	
	if (updatecode == 1) then
		HACK_INFINITY = HACK_INFINITY + 1
		--MF_alert("code being updated!")
		
		MF_removeblockeffect(0)
		
		if (HACK_INFINITY < 200) then
			local checkthese = {}
			local wordidentifier = ""
			wordunits,wordidentifier = findwordunits()
			
			if (#wordunits > 0) then
				for i,v in ipairs(wordunits) do
					if testcond(v[2],v[1]) then
						table.insert(checkthese, v[1])
					end
				end
			end
			
			features = {}
			featureindex = {}
			visualfeatures = {}
			notfeatures = {}
			local firstwords = {}
			local alreadyused = {}
			
			addbaserule("text","is","push")
			addbaserule("level","is","stop")
			addbaserule("cursor","is","select")
			addbaserule("text_ice","is","push")
			addbaserule("text_ice","is","open")
			
			if (#codeunits > 0) then
				for i,v in ipairs(codeunits) do
					table.insert(checkthese, v)
				end
			end
		
			if (#checkthese > 0) then
				for iid,unitid in ipairs(checkthese) do
					local unit = mmf.newObject(unitid)
					local x,y = unit.values[XPOS],unit.values[YPOS]
					local ox,oy,nox,noy = 0,0
					local tileid = x + y * roomsizex

					setcolour(unit.fixed)
					
					if (alreadyused[tileid] == nil) then
						for i=1,2 do
							local drs = dirs[i+2]
							local ndrs = dirs[i]
							ox = drs[1]
							oy = drs[2]
							nox = ndrs[1]
							noy = ndrs[2]
							
							local hm = codecheck(unitid,ox,oy)
							local hm2 = codecheck(unitid,nox,noy)
							
							if (#hm == 0) and (#hm2 > 0) then
								table.insert(firstwords, {unitid, i})
								
								alreadyused[tileid] = 1
							end
						end
					end
				end
				
				docode(firstwords,wordunits)
				grouprules()
				playrulesound = postrules(alreadyrun)
				updatecode = 0
				
				local newwordunits,newwordidentifier = findwordunits()
				
				--MF_alert("ID comparison: " .. newwordidentifier .. " - " .. wordidentifier)
				
				if (newwordidentifier ~= wordidentifier) then
					updatecode = 1
					code(true)
				else
					domaprotation()
				end
			end
		else
			destroylevel("infinity")
			return
		end
	end
	
	if (alreadyrun == false) then
		local rulesoundshort = ""
		alreadyrun = true
		if playrulesound then
			local pmult,sound = checkeffecthistory("rule")
			rulesoundshort = sound
			local rulename = "rule" .. tostring(math.random(1,5)) .. rulesoundshort
			MF_playsound(rulename)
		end
	end
end

function levelblock()
	local unlocked = false
	local things = {}
	local donethings = {}
	
	local emptythings = {}
	
	if (featureindex["level"] ~= nil) then
		for i,v in ipairs(featureindex["level"]) do
			table.insert(things, v)
		end
	end
	
	if (featureindex["empty"] ~= nil) then
		for i,v in ipairs(featureindex["empty"]) do
			local rule = v[1]
			
			if (rule[1] == "empty") and (rule[2] == "is") then
				table.insert(emptythings, v)
			end
		end
	end
	
	if (#emptythings > 0) then
		for i=1,roomsizex-2 do
			for j=1,roomsizey-2 do
				local tileid = i + j * roomsizex
				
				if (unitmap[tileid] == nil) or (#unitmap[tileid] == 0) then
					--MF_alert(tostring(i) .. ", " .. tostring(j))
					local keypair = ""
					local winpair = ""
					local unlock = false
					local victory = false
					
					for a,rules in ipairs(emptythings) do
						local rule = rules[1]
						local conds = rules[2]
						
						if (rule[3] == "open") and testcond(conds,2,i,j) then
							if (string.len(keypair) == 0) then
								keypair = "shut"
							elseif (keypair == "open") then
								unlock = true
							end
						elseif (rule[3] == "shut") and testcond(conds,2,i,j) then
							if (string.len(keypair) == 0) then
								keypair = "open"
							elseif (keypair == "shut") then
								unlock = true
							end
						end
						
						if (rule[3] == "win") and testcond(conds,2,i,j) then
							if (string.len(winpair) == 0) then
								winpair = "you"
							elseif (winpair == "win") then
								victory = true
							end
						elseif (rule[3] == "you") and testcond(conds,2,i,j) then
							if (string.len(winpair) == 0) then
								winpair = "win"
							elseif (winpair == "you") then
								victory = true
							end
						end
					end
					
					if unlock then
						setsoundname("turn",7)
						
						if (math.random(1,4) == 1) then
							MF_particles("unlock",i,j,1,2,4,1,1)
						end
						
						delete(2,i,j)
					end
					
					if victory then
						MF_win()
					end
				end
			end
		end
	end
	
	if (#things > 0) then
		for i,rules in ipairs(things) do
			local rule = rules[1]
			local conds = rules[2]
			
			if testcond(conds,1) and (rule[2] == "is") then
				local action = rule[3]
				
				if (action == "win") then
					local yous = findfeature(nil,"is","you")
					local yous2 = findfeature(nil,"is","you2")
					
					if (yous == nil) then
						yous = {}
					end
					
					if (yous2 ~= nil) then
						for i,v in ipairs(yous2) do
							table.insert(yous, v)
						end
					end
					
					local canwin = false
					
					if (yous ~= nil) then
						for a,b in ipairs(yous) do
							local allyous = findall(b)
							local doit = false
							
							for c,d in ipairs(allyous) do
								if floating_level(d) then
									doit = true
								end
							end
							
							if doit then
								canwin = true
								for c,d in ipairs(allyous) do
									local unit = mmf.newObject(d)
									local pmult,sound = checkeffecthistory("win")
									MF_particles("win",unit.values[XPOS],unit.values[YPOS],10 * pmult,2,4,1,1)
								end
							end
						end
					end
					
					if (hasfeature("level","is","you",1) ~= nil) or (hasfeature("level","is","you2",1) ~= nil) then
						canwin = true
					end
					
					if canwin then
						MF_win()
					end
				elseif (action == "defeat") then
					local yous = findfeature(nil,"is","you")
					local yous2 = findfeature(nil,"is","you2")
					
					if (yous == nil) then
						yous = {}
					end
					
					if (yous2 ~= nil) then
						for i,v in ipairs(yous2) do
							table.insert(yous, v)
						end
					end
					
					if (yous ~= nil) then
						for a,b in ipairs(yous) do
							if (b[1] ~= "level") then
								local allyous = findall(b)
								
								if (#allyous > 0) then
									for c,d in ipairs(allyous) do
										if (issafe(d) == false) and floating_level(d) then
											local unit = mmf.newObject(d)
											
											local pmult,sound = checkeffecthistory("defeat")
											MF_particles("destroy",unit.values[XPOS],unit.values[YPOS],5 * pmult,0,3,1,1)
											setsoundname("removal",1,sound)
											generaldata.values[SHAKE] = 2
											delete(d)
										end
									end
								end
							else
								destroylevel()
							end
						end
					end
				elseif (action == "weak") then
					for i,unit in ipairs(units) do
						local name = unit.strings[UNITNAME]
						if (unit.strings[UNITTYPE] == "text") then
							name = "text"
						end
						
						if floating_level(unit.fixed) and (issafe(unit.fixed) == false) then
							destroylevel()
						end
					end
				elseif (action == "hot") then
					local melts = findfeature(nil,"is","melt")
					
					if (melts ~= nil) then
						for a,b in ipairs(melts) do
							local allmelts = findall(b)
							
							if (#allmelts > 0) then
								for c,d in ipairs(allmelts) do
									if (issafe(d) == false) and floating_level(d) then
										local unit = mmf.newObject(d)
										
										local pmult,sound = checkeffecthistory("hot")
										MF_particles("smoke",unit.values[XPOS],unit.values[YPOS],5 * pmult,0,1,1,1)
										generaldata.values[SHAKE] = 2
										setsoundname("removal",9,sound)
										delete(d)
									end
								end
							end
						end
					end
				elseif (action == "melt") then
					local hots = findfeature(nil,"is","hot")
					
					if (hots ~= nil) then
						for a,b in ipairs(hots) do
							local doit = false
							
							if (b[1] ~= "level") then
								local allhots = findall(b)
								
								for c,d in ipairs(allhots) do
									if floating_level(d) then
										doit = true
									end
								end
							else
								doit = true
							end
							
							if doit then
								destroylevel()
							end
						end
					end
				elseif (action == "open") then
					local shuts = findfeature(nil,"is","shut")
					
					if (shuts ~= nil) then
						for a,b in ipairs(shuts) do
							local doit = false
							
							if (b[1] ~= "level") then
								local allshuts = findall(b)
								
								
								for c,d in ipairs(allshuts) do
									if floating_level(d) then
										doit = true
									end
								end
							else
								doit = true
							end
							
							if doit then
								destroylevel()
							end
						end
					end
				elseif (action == "shut") then
					local opens = findfeature(nil,"is","open")
					
					if (opens ~= nil) then
						for a,b in ipairs(opens) do
							local doit = false
							
							if (b[1] ~= "level") then
								local allopens = findall(b)
								
								for c,d in ipairs(allopens) do
									if floating_level(d) then
										doit = true
									end
								end
							else
								doit = true
							end
							
							if doit then
								destroylevel()
							end
						end
					end
				elseif (action == "sink") then
					for a,unit in ipairs(units) do
						local name = unit.strings[UNITNAME]
						if (unit.strings[UNITTYPE] == "text") then
							name = "text"
						end
						if floating_level(unit.fixed) then
							destroylevel()
						end
					end
				elseif (action == "tele") then
					for a,unit in ipairs(units) do
						local x,y = unit.values[XPOS],unit.values[YPOS]
						
						local tx,ty = math.random(1,roomsizex-2),math.random(1,roomsizey-2)
						
						if (issafe(unit.fixed) == false) and floating_level(unit.fixed) then
							update(unit.fixed,tx,ty)
							
							local pmult,sound = checkeffecthistory("tele")
							MF_particles("glow",x,y,5 * pmult,1,4,1,1)
							MF_particles("glow",tx,ty,5 * pmult,1,4,1,1)
							setsoundname("turn",6,sound)
						end
					end
				elseif (action == "move") then
					local dir = mapdir
					
					local drs = ndirs[dir + 1]
					local ox,oy = drs[1],drs[2]
					
					addundo({"levelupdate",Xoffset,Yoffset,Xoffset + ox * tilesize,Yoffset + oy * tilesize,dir,dir})
					MF_scrollroom(ox * tilesize,oy * tilesize)
					updateundo = true
				elseif (action == "fall") then
					local drop = 20
					local dir = mapdir
					
					addundo({"levelupdate",Xoffset,Yoffset,Xoffset,Yoffset + tilesize * drop,dir,dir})
					MF_scrollroom(0,tilesize * drop)
					updateundo = true
				end
			end
		end
	end
	
	if (featureindex["done"] ~= nil) then
		for i,v in ipairs(featureindex["done"]) do
			table.insert(donethings, v)
		end
	end
	
	if (#donethings > 0) and (generaldata.values[WINTIMER] == 0) then
		for i,rules in ipairs(donethings) do
			local rule = rules[1]
			local conds = rules[2]
			
			if (#conds == 0) then
				if (rule[1] == "all") and (rule[2] == "is") and (rule[3] == "done") then
					MF_playsound("doneall_c")
					MF_allisdone()
				end
			end
		end
	end
	
	if (generaldata.strings[WORLD] == generaldata.strings[BASEWORLD]) and (generaldata.strings[CURRLEVEL] == "305level") then
		local numfound = false
		
		if (featureindex["image"] ~= nil) then
			for i,v in ipairs(featureindex["image"]) do
				local rule = v[1]
				local conds = v[2]
				
				if (rule[1] == "image") and (rule[2] == "is") and (#conds == 0) then
					local num = rule[3]
					
					local nums = {
						one = {1, "a very early version of the game."},
						two = {2, "mockups made while figuring out the artstyle."},
						three = {3, "early tests for different palettes."},
						four = {4, "a very early version of the map."},
						five = {5, "how the map was supposed to be laid out."},
						six = {6, "first iterations of a non-abstract world map."},
						seven = {7, "trying to figure out the pulling mechanic."},
						eight = {8, "watercolour - title"},
						nine = {9, "watercolour - space"},
						ten = {10, "watercolour - keke"},
						fourteen = {11, "sudden inspiration led to a three-eyed baba."},
						sixteen = {12, "the pushing system was very hard to construct."},
						minusone = {13, "some to-do notes, in finnish!"},
						minustwo = {14, "a mockup of the map."},
						minusthree = {15, "trying to plot out the 'default' objects."},
						minusten = {16, "a flowchart for seeing which levels are 'related'."},
						win = {0, "win"}
					}
					
					if (nums[num] ~= nil) then
						local data = nums[num]
						
						if (data[2] ~= "win") then
							MF_setart(data[1], data[2])
							numfound = true
						else
							local yous = findallfeature(nil,"is","you",true)
							local yous2 = findallfeature(nil,"is","you2",true)
							
							if (#yous2 > 0) then
								for a,b in ipairs(yous2) do
									table.insert(yous, b)
								end
							end
							
							for a,b in ipairs(yous) do
								local unit = mmf.newObject(b)
								local x,y = unit.values[XPOS],unit.values[YPOS]
								
								if (x > roomsizex - 16) then
									local pmult = checkeffecthistory("win")
									
									MF_particles("win",x,y,10 * pmult,2,4,1,1)
									MF_win()
									break
								end
							end
						end
					end
				end
			end
		end
			
		if (numfound == false) then
			MF_setart(0,"")
		end
	end
	
	if unlocked then
		setsoundname("turn",7)
	end
end