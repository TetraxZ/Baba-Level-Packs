local mod = {}

-- options.lua to edit
mod.enabled = {}
mod.tile = {}
mod.macros = {}

mod.tilecount = 0

-- Calls when a world is first loaded
function mod.load(dir)
	-- Load mod code
	loadscript(dir .. "blocks")
	loadscript(dir .. "rules")
end

-- Calls when another world is loaded while this mod is active
function mod.unload(dir)
	-- Unload mod code
	loadscript("Data/blocks")
	loadscript("Data/rules")
end
return mod