function code(alreadyrun_)
	local playrulesound = false
	local alreadyrun = alreadyrun_ or false
	
	if (updatecode == 1) then
		HACK_INFINITY = HACK_INFINITY + 1
		--MF_alert("code being updated!")
		
		MF_removeblockeffect(0)
		
		if (HACK_INFINITY < 200) then
			local checkthese = {}
			local wordidentifier = ""
			wordunits,wordidentifier = findwordunits()
			
			if (#wordunits > 0) then
				for i,v in ipairs(wordunits) do
					if testcond(v[2],v[1]) then
						table.insert(checkthese, v[1])
					end
				end
			end
			
			features = {}
			featureindex = {}
			visualfeatures = {}
			notfeatures = {}
			local firstwords = {}
			local alreadyused = {}
			
			addbaserule("text","is","push")
			addbaserule("level","is","stop")
			addbaserule("cursor","is","select")
			addbaserule("text_ice","is","push")
			addbaserule("text_ice","is","open")
			
			if (#codeunits > 0) then
				for i,v in ipairs(codeunits) do
					table.insert(checkthese, v)
				end
			end
		
			if (#checkthese > 0) then
				for iid,unitid in ipairs(checkthese) do
					local unit = mmf.newObject(unitid)
					local x,y = unit.values[XPOS],unit.values[YPOS]
					local ox,oy,nox,noy = 0,0
					local tileid = x + y * roomsizex

					setcolour(unit.fixed)
					
					if (alreadyused[tileid] == nil) then
						for i=1,2 do
							local drs = dirs[i+2]
							local ndrs = dirs[i]
							ox = drs[1]
							oy = drs[2]
							nox = ndrs[1]
							noy = ndrs[2]
							
							local hm = codecheck(unitid,ox,oy)
							local hm2 = codecheck(unitid,nox,noy)
							
							if (#hm == 0) and (#hm2 > 0) then
								table.insert(firstwords, {unitid, i})
								
								alreadyused[tileid] = 1
							end
						end
					end
				end
				
				docode(firstwords,wordunits)
				grouprules()
				playrulesound = postrules(alreadyrun)
				updatecode = 0
				
				local newwordunits,newwordidentifier = findwordunits()
				
				--MF_alert("ID comparison: " .. newwordidentifier .. " - " .. wordidentifier)
				
				if (newwordidentifier ~= wordidentifier) then
					updatecode = 1
					code(true)
				else
					domaprotation()
				end
			end
		else
			destroylevel("infinity")
			return
		end
	end
	
	if (alreadyrun == false) then
		local rulesoundshort = ""
		alreadyrun = true
		if playrulesound then
			local pmult,sound = checkeffecthistory("rule")
			rulesoundshort = sound
			local rulename = "rule" .. tostring(math.random(1,5)) .. rulesoundshort
			MF_playsound(rulename)
		end
	end
end