menufuncs =
{
	main =
	{
		button = "MainMenuButton",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 + f_tilesize * 1
				
				local disable = MF_unfinished()
				local build = generaldata.strings[BUILD]
				
				createbutton("start",x,y,2,11,1,langtext("main_start"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("settings",x,y,2,11,1,langtext("settings"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("custom",x,y,2,11,1,langtext("main_custom"),name,3,2,buttonid,disable)

				y = y + f_tilesize
				
				createbutton("editor",x,y,2,11,1,langtext("main_editor"),name,3,2,buttonid,disable)
				
				y = y + f_tilesize
				
				createbutton("credits",x,y,2,11,1,langtext("credits"),name,3,2,buttonid)
				
				if (build ~= "n") and (build ~= "promo") and (build ~= "m") then
					y = y + f_tilesize
					
					createbutton("quit",x,y,2,11,1,langtext("main_exit"),name,3,2,buttonid)
				end
				
				if (generaldata.strings[LANG] ~= "en") then
					local madeby = langtext("intro_madeby")
					
					writetext(madeby,0,screenw * 0.5,screenh - f_tilesize * 0.8,name,true,1)
				end
				
				local version = "version " .. string.lower( MF_getversion() )
				
				writetext(version,0,f_tilesize * 0.4,screenh - f_tilesize * 0.4,name,false,1)
			end,
		structure =
		{
			{
				{{"start"},},
				{{"settings"},},
				{{"custom"},},
				{{"editor"},},
				{{"credits"},},
				{{"quit"},},
			},
			n = {
				{{"start"},},
				{{"settings"},},
				{{"credits"},},
			},
			promo = {
				{{"start"},},
				{{"settings"},},
				{{"credits"},},
			},
			m = {
				{{"start"},},
				{{"settings"},},
				{{"credits"},},
			},
		}
	},
	pause =
	{
		button = "PauseMenu",
		enter = 
			function(parent,name,buttonid)
				MF_letterclear("editorname")
				editor.values[NAMEFLAG] = 0
				
				local x = f_tilesize * 5
				local y = f_tilesize * 2
				
				local mx = screenw * 0.5
				
				local leveltitle = ""
				if (string.len(generaldata.strings[LEVELNUMBER_NAME]) > 0) then
					leveltitle = generaldata.strings[LEVELNUMBER_NAME] .. ": "
				end
				
				if (editor.values[LEVELTYPE] == 1) then
					leveltitle = ""
				end
				
				displaylevelname(nil,generaldata.strings[CURRLEVEL],2,name,mx,nil,true,leveltitle)
				
				y = y + f_tilesize
				
				createbutton("resume",mx,y,2,8,1,langtext("resume"),name,1,3,buttonid)
				
				y = y + f_tilesize
				
				if (editor.values[INEDITOR] == 0) then
					local returndisable = false
					if (#leveltree <= 1) then
						returndisable = true
					end
					
					if (generaldata.strings[WORLD] == generaldata.strings[BASEWORLD]) and (generaldata.strings[CURRLEVEL] == "200level") then
						returndisable = false
					end
					
					createbutton("return",mx,y,2,8,1,langtext("pause_returnmap"),name,1,3,buttonid,returndisable)
				else
					createbutton("return",mx,y,2,8,1,langtext("pause_returneditor"),name,1,3,buttonid)
				end
				
				y = y + f_tilesize
				
				createbutton("restart",mx,y,2,8,1,langtext("restart"),name,1,3,buttonid)
				
				y = y + f_tilesize
				
				createbutton("settings",mx,y,2,8,1,langtext("settings"),name,1,3,buttonid)
				
				y = y + f_tilesize * 1.5
				
				local mainmenudisable = false
				if (editor.values[INEDITOR] > 0) then
					mainmenudisable = true
				end
				
				createbutton("returnmain",mx,y,2,8,1,langtext("pause_returnmain"),name,1,3,buttonid,mainmenudisable)
				
				y = y + f_tilesize * 1.5
				
				writerules(parent,name,mx,y)
			end,
		structure =
		{
			{
				{{"resume"},},
				{{"return"},},
				{{"restart"},},
				{{"settings"},},
				{{"returnmain"},},
			},
		}
	},
	settings =
	{
		button = "SettingsButton",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = 2 * f_tilesize
				
				local disable = MF_unfinished()
				local build = generaldata.strings[BUILD]
				
				writetext(langtext("settings") .. ":",0,x,y,name,true,2,true)
				
				x = screenw * 0.5 - f_tilesize * 1
				y = y + f_tilesize * 2
				
				writetext(langtext("settings_music") .. ":",0,x - f_tilesize * 11.5,y,name,false,2,true)
				local mvolume = MF_read("settings","settings","music")
				slider("music",x + f_tilesize * 5,y,8,{1,3},{1,4},buttonid,0,100,tonumber(mvolume))
				
				y = y + f_tilesize
				
				writetext(langtext("settings_sound") .. ":",0,x - f_tilesize * 11.5,y,name,false,2,true)
				local svolume = MF_read("settings","settings","sound")
				slider("sound",x + f_tilesize * 5,y,8,{1,3},{1,4},buttonid,0,100,tonumber(svolume))
				
				y = y + f_tilesize
				
				writetext(langtext("settings_repeat") .. ":",0,x - f_tilesize * 11.5,y,name,false,2,true)
				local delay = MF_read("settings","settings","delay")
				slider("delay",x + f_tilesize * 5,y,8,{1,3},{1,4},buttonid,7,20,tonumber(delay))
				
				x = screenw * 0.5
				y = y + f_tilesize * 2
				
				createbutton("language",x,y,2,18,1,langtext("settings_language"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				if (build ~= "n") then
					createbutton("controls",x,y,2,18,1,langtext("controls"),name,3,2,buttonid)
				
					y = y + f_tilesize
				
					local fullscreen = MF_read("settings","settings","fullscreen")
					local s,c = gettoggle(fullscreen)
					createbutton("fullscreen",x,y,2,18,1,langtext("settings_fullscreen"),name,3,2,buttonid,nil,s)
					
					y = y + f_tilesize
				end
				
				local grid = MF_read("settings","settings","grid")
				s,c = gettoggle(grid)
				createbutton("grid",x,y,2,18,1,langtext("settings_grid"),name,3,2,buttonid,nil,s)
				
				y = y + f_tilesize
				
				local wobble = MF_read("settings","settings","wobble")
				s,c = gettoggle(wobble)
				createbutton("wobble",x,y,2,18,1,langtext("settings_wobble"),name,3,2,buttonid,nil,s)
				
				y = y + f_tilesize
				
				local particles = MF_read("settings","settings","particles")
				s,c = gettoggle(particles)
				createbutton("particles",x,y,2,18,1,langtext("settings_particles"),name,3,2,buttonid,nil,s)
				
				y = y + f_tilesize
				
				local particles = MF_read("settings","settings","shake")
				s,c = gettoggle(particles)
				createbutton("shake",x,y,2,18,1,langtext("settings_shake"),name,3,2,buttonid,nil,s)
				
				y = y + f_tilesize
				
				local contrast = MF_read("settings","settings","contrast")
				s,c = gettoggle(contrast)
				createbutton("contrast",x,y,2,18,1,langtext("settings_palette"),name,3,2,buttonid,nil,s)
				
				y = y + f_tilesize
				
				local restartask = MF_read("settings","settings","restartask")
				s,c = gettoggle(restartask)
				createbutton("restartask",x,y,2,18,1,langtext("settings_restart"),name,3,2,buttonid,nil,s)
				
				y = y + f_tilesize
				
				--[[
				local zoom = MF_read("settings","settings","zoom")
				s,c = gettoggle(zoom)
				createbutton("zoom",x,y,2,16,1,langtext("settings_zoom"),name,3,2,buttonid,nil,s)
				]]--
				
				writetext(langtext("settings_zoom") .. ":",0,x - f_tilesize * 15.5,y,name,false,2,true)
				
				local zoom = tonumber(MF_read("settings","settings","zoom")) or 0
				createbutton("zoom1",x - f_tilesize * 4.5,y,2,7,1,langtext("zoom1"),name,3,2,buttonid,nil)
				createbutton("zoom2",x + f_tilesize * 3.5,y,2,7,1,langtext("zoom2"),name,3,2,buttonid,nil)
				createbutton("zoom3",x + f_tilesize * 11.5,y,2,7,1,langtext("zoom3"),name,3,2,buttonid,nil)
				
				makeselection({"zoom2","zoom1","zoom3"},tonumber(zoom) + 1)
				
				y = y + f_tilesize
				
				createbutton("return",x,y,2,18,1,langtext("return"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"music",-392},},
				{{"sound",-392},},
				{{"delay",-392},},
				{{"language"},},
				{{"controls"},},
				{{"fullscreen"},},
				{{"grid"},},
				{{"wobble"},},
				{{"particles"},},
				{{"shake"},},
				{{"contrast"},},
				{{"restartask"},},
				{{"zoom1"},{"zoom2"},{"zoom3"},},
				{{"return"},},
			},
			n = {
				{{"music",-392},},
				{{"sound",-392},},
				{{"delay",-392},},
				{{"language"},},
				{{"grid"},},
				{{"wobble"},},
				{{"particles"},},
				{{"shake"},},
				{{"contrast"},},
				{{"restartask"},},
				{{"zoom1"},{"zoom2"},{"zoom3"},},
				{{"return"},},
			},
		}
	},
	controls =
	{
		button = "ControlsButton",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = 3 * f_tilesize
				
				writetext(langtext("controls_setup") .. ":",0,x,y,name,true,2,true)
				
				local pad,padname = MF_profilefound()
				local padtext = langtext("controls_noconnectedgamepad")
				
				if (pad ~= nil) then
					if pad then
						padtext = langtext("controls_gamepadname") .. ": " .. string.lower(string.sub(padname, 1, math.min(string.len(padname), 25)))
					else
						padtext = langtext("controls_unknowngamepad")
					end
				end
				
				y = y + f_tilesize * 1
				
				writetext(padtext,0,x,y,name,true,2,true)

				y = y + f_tilesize * 2
				
				createbutton("detect",x,y,2,16,1,langtext("controls_detectgamepad"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("gamepad",x,y,2,16,1,langtext("controls_gamepadsetup"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("default_gamepad",x,y,2,16,1,langtext("controls_defaultgamepad"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				local disablegamepad = generaldata4.values[DISABLEGAMEPAD] + 1
				local disablegamepad_opts = {"controls_disablegamepad_off","controls_disablegamepad_on"}
				createbutton("disable_gamepad",x,y,2,16,1,langtext(disablegamepad_opts[disablegamepad]),name,3,2,buttonid)
				
				y = y + f_tilesize * 1.5
				
				createbutton("keyboard",x,y,2,16,1,langtext("controls_keysetup"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("default_keyboard",x,y,2,16,1,langtext("controls_defaultkey"),name,3,2,buttonid)

				y = y + f_tilesize * 2
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"detect"},},
				{{"gamepad"},},
				{{"default_gamepad"},},
				{{"disable_gamepad"},},
				{{"keyboard"},},
				{{"default_keyboard"},},
				{{"return"},},
			},
		}
	},
	gamepad =
	{
		button = "KeyConfigButton",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = 3 * f_tilesize
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)

				x = x + f_tilesize * 1.5
				y = y + f_tilesize * 2
				
				createbutton("move",x - f_tilesize * 8,y,2,6,1,langtext("move"),name,3,2,buttonid)
				createcontrolicon("move",true,x - f_tilesize * 3.5,y,buttonid)
				
				createbutton("move2",x + f_tilesize * 3,y,2,6,1,langtext("move") .. " 2",name,3,2,buttonid)
				createcontrolicon("move2",true,x + f_tilesize * 7.5,y,buttonid)
				
				y = y + f_tilesize * 1.4
				
				createbutton("idle",x - f_tilesize * 8,y,2,6,1,langtext("idle"),name,3,2,buttonid)
				createcontrolicon("idle",true,x - f_tilesize * 3.5,y,buttonid)
				
				createbutton("idle2",x + f_tilesize * 3,y,2,6,1,langtext("idle") .. " 2",name,3,2,buttonid)
				createcontrolicon("idle2",true,x + f_tilesize * 7.5,y,buttonid)
				
				y = y + f_tilesize * 1.4
				
				createbutton("undo",x - f_tilesize * 8,y,2,6,1,langtext("undo"),name,3,2,buttonid)
				createcontrolicon("undo",true,x - f_tilesize * 3.5,y,buttonid)
				
				createbutton("undo2",x + f_tilesize * 3,y,2,6,1,langtext("undo") .. " 2",name,3,2,buttonid)
				createcontrolicon("undo2",true,x + f_tilesize * 7.5,y,buttonid)
				
				y = y + f_tilesize * 1.4
				
				createbutton("restart",x - f_tilesize * 8,y,2,6,1,langtext("controls_restart"),name,3,2,buttonid)
				createcontrolicon("restart",true,x - f_tilesize * 3.5,y,buttonid)
				
				createbutton("restart2",x + f_tilesize * 3,y,2,6,1,langtext("controls_restart") .. " 2",name,3,2,buttonid)
				createcontrolicon("restart2",true,x + f_tilesize * 7.5,y,buttonid)
				
				y = y + f_tilesize * 1.4
				
				createbutton("confirm",x - f_tilesize * 8,y,2,6,1,langtext("confirm"),name,3,2,buttonid)
				createcontrolicon("confirm",true,x - f_tilesize * 3.5,y,buttonid)
				
				createbutton("confirm2",x + f_tilesize * 3,y,2,6,1,langtext("confirm") .. " 2",name,3,2,buttonid)
				createcontrolicon("confirm2",true,x + f_tilesize * 7.5,y,buttonid)
				
				y = y + f_tilesize * 1.4
				
				createbutton("pause",x - f_tilesize * 3,y,2,8,1,langtext("pause"),name,3,2,buttonid)
				createcontrolicon("pause",true,x + f_tilesize * 3.5,y,buttonid)
			end,
		structure =
		{
			{
				{{"return"},},
				{{"move"},{"move2"}},
				{{"idle"},{"idle2"}},
				{{"undo"},{"undo2"}},
				{{"restart"},{"restart2"}},
				{{"confirm"},{"confirm2"}},
				{{"pause"},},
			},
		}
	},
	keyboard =
	{
		button = "KeyConfigButton",
		enter = 
			function(parent,name,buttonid)
				local x = roomsizex * f_tilesize * 0.5 * spritedata.values[TILEMULT]
				local y = 3 * f_tilesize
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)

				y = y + f_tilesize * 2
				
				createbutton("right",x - f_tilesize * 7,y,2,6,1,langtext("right"),name,3,2,buttonid)
				createcontrolicon("right",false,x - f_tilesize * 2.5,y,buttonid)
				
				createbutton("right2",x + f_tilesize * 4,y,2,6,1,langtext("right") .. " 2",name,3,2,buttonid)
				createcontrolicon("right2",false,x + f_tilesize * 8.5,y,buttonid)
				
				y = y + f_tilesize
				
				createbutton("up",x - f_tilesize * 7,y,2,6,1,langtext("up"),name,3,2,buttonid)
				createcontrolicon("up",false,x - f_tilesize * 2.5,y,buttonid)
				
				createbutton("up2",x + f_tilesize * 4,y,2,6,1,langtext("up") .. " 2",name,3,2,buttonid)
				createcontrolicon("up2",false,x + f_tilesize * 8.5,y,buttonid)
				
				y = y + f_tilesize
				
				createbutton("left",x - f_tilesize * 7,y,2,6,1,langtext("left"),name,3,2,buttonid)
				createcontrolicon("left",false,x - f_tilesize * 2.5,y,buttonid)
				
				createbutton("left2",x + f_tilesize * 4,y,2,6,1,langtext("left") .. " 2",name,3,2,buttonid)
				createcontrolicon("left2",false,x + f_tilesize * 8.5,y,buttonid)
				
				y = y + f_tilesize
				
				createbutton("down",x - f_tilesize * 7,y,2,6,1,langtext("down"),name,3,2,buttonid)
				createcontrolicon("down",false,x - f_tilesize * 2.5,y,buttonid)
				
				createbutton("down2",x + f_tilesize * 4,y,2,6,1,langtext("down") .. " 2",name,3,2,buttonid)
				createcontrolicon("down2",false,x + f_tilesize * 8.5,y,buttonid)
				
				y = y + f_tilesize * 1.2
				
				createbutton("idle",x - f_tilesize * 7,y,2,6,1,langtext("idle"),name,3,2,buttonid)
				createcontrolicon("idle",false,x - f_tilesize * 2.5,y,buttonid)
				
				createbutton("idle2",x + f_tilesize * 4,y,2,6,1,langtext("idle") .. " 2",name,3,2,buttonid)
				createcontrolicon("idle2",false,x + f_tilesize * 8.5,y,buttonid)
				
				y = y + f_tilesize
				
				createbutton("undo",x - f_tilesize * 7,y,2,6,1,langtext("undo"),name,3,2,buttonid)
				createcontrolicon("undo",false,x - f_tilesize * 2.5,y,buttonid)
				
				createbutton("undo2",x + f_tilesize * 4,y,2,6,1,langtext("undo") .. " 2",name,3,2,buttonid)
				createcontrolicon("undo2",false,x + f_tilesize * 8.5,y,buttonid)
				
				y = y + f_tilesize
				
				createbutton("restart",x - f_tilesize * 7,y,2,6,1,langtext("controls_restart"),name,3,2,buttonid)
				createcontrolicon("restart",false,x - f_tilesize * 2.5,y,buttonid)
				
				createbutton("restart2",x + f_tilesize * 4,y,2,6,1,langtext("controls_restart") .. " 2",name,3,2,buttonid)
				createcontrolicon("restart2",false,x + f_tilesize * 8.5,y,buttonid)
				
				y = y + f_tilesize
				
				createbutton("confirm",x - f_tilesize * 7,y,2,6,1,langtext("confirm"),name,3,2,buttonid)
				createcontrolicon("confirm",false,x - f_tilesize * 2.5,y,buttonid)
				
				createbutton("confirm2",x + f_tilesize * 4,y,2,6,1,langtext("confirm") .. " 2",name,3,2,buttonid)
				createcontrolicon("confirm2",false,x + f_tilesize * 8.5,y,buttonid)
				
				y = y + f_tilesize * 1.2
				
				createbutton("pause",x - f_tilesize * 3,y,2,8,1,langtext("pause"),name,3,2,buttonid)
				createcontrolicon("pause",false,x + f_tilesize * 3.5,y,buttonid)
			end,
		structure =
		{
			{
				{{"return"},},
				{{"right"},{"right2"}},
				{{"up"},{"up2"}},
				{{"left"},{"left2"}},
				{{"down"},{"down2"}},
				{{"move"},{"move2"}},
				{{"idle"},{"idle2"}},
				{{"undo"},{"undo2"}},
				{{"restart"},{"restart2"}},
				{{"confirm"},{"confirm2"}},
				{{"pause"},},
			},
		}
	},
	change_keyboard =
	{
		button = "Change",
		enter =
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5
				writetext(langtext("controls_pressany"),0,x,y,name,true,2,true)
			end,
	},
	change_gamepad =
	{
		button = "Change",
		enter =
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5
				writetext(langtext("controls_pressany"),0,x,y,name,true,2,true)
			end,
	},
	editor_start =
	{
		button = "EditLevels",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 5.5
				
				writetext(langtext("editor_start_title"),0,x,y,name,true,1)
				
				y = y + f_tilesize * 3
				
				local enableworlds = true
				local build = generaldata.strings[BUILD]
				
				local enableworlds_ = tonumber(MF_read("settings","editor","mode")) or 0
				if (enableworlds_ == 1) then
					enableworlds = false
				end
				
				createbutton("editor_start_level",x,y,2,16,2,langtext("editor_start_level"),name,3,2,buttonid)
				
				if (build ~= "n") and (build ~= "m") then
					y = y + f_tilesize * 2
					
					createbutton("editor_start_world",x,y,2,16,2,langtext("editor_start_world"),name,3,2,buttonid,enableworlds)
				end
				
				y = y + f_tilesize * 2
				
				createbutton("editor_start_settings",x,y,2,16,2,langtext("editor_start_settings"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"editor_start_level"},},
				{{"editor_start_world"},},
				{{"editor_start_settings"},},
				{{"return"},},
			},
			n = {
				{{"editor_start_level"},},
				{{"editor_start_settings"},},
				{{"return"},},
			},
			m = {
				{{"editor_start_level"},},
				{{"editor_start_settings"},},
				{{"return"},},
			},
		}
	},
	editor_start_settings =
	{
		button = "EditLevelsSettings",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 4
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
				
				y = y + f_tilesize * 3
				
				if (build ~= "m") then
					createbutton("editor_settings_controls",x,y,2,16,1,langtext("editor_settings_controls"),name,3,2,buttonid)
				
					y = y + f_tilesize * 1.5
				end
				
				createbutton("editor_settings_advanced",x,y,2,16,1,langtext("editor_settings_advanced"),name,3,2,buttonid)
				
				makeselection({"","editor_settings_advanced"},editor2.values[ADVANCEDWORDS] + 1)
				
				if (build ~= "n") and (build ~= "m") then
					y = y + f_tilesize * 1.5
					
					createbutton("editor_settings_mod",x,y,2,16,1,langtext("editor_settings_mod"),name,3,2,buttonid,enableworlds)
					
					makeselection({"","editor_settings_mod"},editor2.values[EXTENDEDMODE] + 1)
				end
			end,
		structure =
		{
			{
				{{"return"},},
				{{"editor_settings_controls"},},
				{{"editor_settings_advanced"},},
				{{"editor_settings_mod"},},
			},
			n = {
				{{"return"},},
				{{"editor_settings_controls"},},
				{{"editor_settings_advanced"},},
			},
			m = {
				{{"return"},},
				{{"editor_settings_advanced"},},
			},
		}
	},
	world =
	{
		scrolling = 1,
		button = "WorldChoice",
		enter = 
			function(parent,name,buttonid)
				menudata_customscript.worldlist(parent,name,buttonid)
			end,
	},
	level =
	{
		scrolling = 1,
		button = "LevelButton",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = f_tilesize * 0.5
				
				writetext(langtext("editor_editlevel") .. ":",0,x,y,name,true,2)
				
				y = y + f_tilesize * 2
				
				createbutton("newlevel",x,y,2,10,1,langtext("editor_newlevel"),name,3,2,buttonid)
				
				createbutton("return",x,y + f_tilesize * 2,2,10,1,langtext("editor_returntoworldlist"),name,3,2,buttonid)
				
				--x = x + roomsizex * f_tilesize * 0.5 * spritedata.values[TILEMULT]
				
				--createbutton("deflevel",x,y,2,10,1,"set default level",name,3,2,buttonid)
				
				--createbutton("startlevel",x,y + f_tilesize,2,10,1,"set first level",name,3,2,buttonid)
				
				MF_visible("LevelButton",1)
				
				editor.values[STATE] = 0
			end,
		leave = 
			function(parent,name)
				MF_delete("LevelButton")
				MF_letterclear("leveltext")
				MF_letterclear("nametext")
			end,
		submenu_leave =
			function(parent,name)
				MF_visible("LevelButton",0)
				MF_letterclear("nametext")
			end,
	},
	name =
	{
		enter = 
			function(parent,name)
				local x = screenw * 0.5
				local y = f_tilesize * 1.5
				writetext(langtext("editor_entername") .. ":",0,x,y,name,true)
			end,
		leave = 
			function(parent,name)
				MF_delete("LetterButton")
				MF_letterclear("nametext")
			end,
	},
	editor =
	{
		enter = 
			function(parent,name)
				local levelname = generaldata.strings[LEVELNAME]
				local level = generaldata.strings[CURRLEVEL]
				displaylevelname(levelname,level,nil,"editorname",nil,nil,true)
				
				local x = screenw - f_tilesize * 3
				local y = f_tilesize * 0.5
				
				createbutton("menu",x,y,2,6,1,langtext("editor_mainmenu"),name,3,2)
				
				x = x - f_tilesize * 6
				
				createbutton("settingsmenu",x,y,2,6,1,langtext("editor_settingsmenu"),name,3,2)
				
				x = x - f_tilesize * 6
				
				createbutton("objects",x,y,2,6,1,langtext("editor_objectlist"),name,3,2)
				
				x = x - f_tilesize * 4.5
				
				createbutton("save",x,y,2,3,1,langtext("editor_savelevel"),name,3,2)
				
				x = screenw - f_tilesize * 0.75
				y = f_tilesize * 1.5
				
				createbutton("layer1",x,y,2,1.5,1,langtext("editor_l1"),name,3,2)
				
				y = y + f_tilesize
				
				createbutton("layer2",x,y,2,1.5,1,langtext("editor_l2"),name,3,2)
				
				y = y + f_tilesize
				
				createbutton("layer3",x,y,2,1.5,1,langtext("editor_l3"),name,3,2)
				
				makeselection({"layer1","layer2","layer3"},editor.values[LAYER] + 1)
				
				editor.values[STATE] = 0
			end,
		leave = 
			function(parent,name)
				MF_delete("EditorButton")
			end,
		submenu_leave = 
			function(parent,name)
				MF_visible("EditorButton",0)
			end,
		submenu_return = 
			function(parent,name)
				MF_visible("EditorButton",1)
			end,
	},
	editorsettingsmenu =
	{
		button = "EditorSettingsMenuButton",
		enter = 
			function(parent,name,buttonid)
				MF_menubackground(true)
				local x = screenw * 0.5
				local y = f_tilesize * 1.5
				
				y = y + f_tilesize * 1.5
				
				createbutton("closemenu",x,y,2,16,1,langtext("editor_menu_close"),name,3,2,buttonid)
				
				y = y + f_tilesize * 1.5
				local refx = x
				local lx = refx - f_tilesize * 14
				local mx = refx - f_tilesize * 8
				local rx = refx + f_tilesize * 8
				
				writetext(langtext("editor_levelmenu_name") .. ":",0,lx,y,name,false,nil,nil,{2,4})
				writetext(generaldata.strings[LEVELNAME],0,mx,y,name,false)
				createbutton("rename",rx,y,2,10,1,langtext("editor_levelmenu_rename"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_levelmenu_author") .. ":",0,lx,y,name,false,nil,nil,{2,4})
				local author = editor2.strings[AUTHOR]
				if (string.len(author) == 0) then
					author = langtext("undefined")
				end
				writetext(author,0,mx,y,name,false)
				createbutton("author",rx,y,2,10,1,langtext("editor_levelmenu_changeauthor"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_levelmenu_difficulty") .. ":",0,lx,y,name,false,nil,nil,{2,4})
				local difficulty = editor2.strings[DIFFICULTY]
				if (string.len(difficulty) == 0) then
					difficulty = "^ ^ ^ ^ ^ ^ ^ ^ ^ ^ "
				end
				writetext(difficulty,0,mx,y,name,false)
				createbutton("diff-",rx - f_tilesize * 3,y,2,4,1,langtext("editor_levelmenu_diffminus"),name,3,2,buttonid)
				createbutton("diff+",rx + f_tilesize * 3,y,2,4,1,langtext("editor_levelmenu_diffplus"),name,3,2,buttonid)
				
				y = y + f_tilesize * 1.5
				
				writetext(langtext("editor_levelmenu_music") .. ":",0,lx,y,name,false,nil,nil,{2,4})
				writetext(editor2.strings[LEVELMUSIC],0,mx,y,name,false)
				createbutton("music",rx,y,2,10,1,langtext("editor_levelmenu_changemusic"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_levelmenu_particles") .. ":",0,lx,y,name,false,nil,nil,{2,4})
				local levelparts = editor2.strings[LEVELPARTICLES]
				if (string.len(levelparts) == 0) then
					levelparts = langtext("none")
				end
				writetext(levelparts,0,mx,y,name,false)
				createbutton("particles",rx,y,2,10,1,langtext("editor_levelmenu_changeparticles"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_levelmenu_palette") .. ":",0,lx,y,name,false,nil,nil,{2,4})
				writetext(MF_getpalettename(),0,mx,y,name,false)
				createbutton("palette",rx,y,2,10,1,langtext("editor_levelmenu_changepalette"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_levelmenu_levelsize") .. ":",0,lx,y,name,false,nil,nil,{2,4})
				local sizetext = langtext("editor_levelmenu_levelwidth") .. " " .. tostring(roomsizex) .. ", " .. langtext("editor_levelmenu_levelheight") .. " " .. tostring(roomsizey)
				writetext(sizetext,0,mx,y,name,false)
				createbutton("levelsize",rx,y,2,10,1,langtext("editor_levelmenu_changelevelsize"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				if (generaldata.strings[BUILD] ~= "n") then
					local enableworlds = true
					local enableworlds_ = tonumber(MF_read("settings","editor","mode")) or 0
					if (enableworlds_ == 1) then
						enableworlds = false
					end
					createbutton("mapsetup",x,y,2,16,1,langtext("editor_levelmenu_mapsetup"),name,3,2,buttonid,enableworlds)
					
					y = y + f_tilesize * 2
				end
			end,
		structure =
		{
			n = {
				{{"closemenu"},},
				{{"rename"},},
				{{"author"},},
				{{"diff-"},{"diff+"},},
				{{"music"},},
				{{"particles"},},
				{{"palette"},},
				{{"levelsize"},},
			},
			{
				{{"closemenu"},},
				{{"rename"},},
				{{"author"},},
				{{"diff-"},{"diff+"},},
				{{"music"},},
				{{"particles"},},
				{{"palette"},},
				{{"levelsize"},},
				{{"mapsetup"},},
			},
		}
	},
	editormenu =
	{
		button = "EditorMenuButton",
		enter = 
			function(parent,name,buttonid)
				MF_menubackground(true)
				
				local x = screenw * 0.5
				local y = f_tilesize * 3.0
				
				createbutton("closemenu",x,y,2,16,1,langtext("editor_menu_close"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("test",x,y,2,16,1,langtext("editor_menu_test"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("upload",x,y,2,16,1,langtext("editor_menu_upload"),name,3,2,buttonid)
				
				y = y + f_tilesize * 1.5
				
				createbutton("return",x,y,2,16,1,langtext("editor_menu_return"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("theme",x,y,2,16,1,langtext("editor_menu_themes"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("delete",x,y,2,16,1,langtext("editor_menu_delete"),name,3,2,buttonid)
			end,
		submenu_return =
			function(parent,name)
				MF_visible("EditorMenuButton",1)
				local x = f_tilesize * 0.5
				local y = f_tilesize * 0.5

				if (parent == "name") then
					MF_letterclear("editorname")
					writetext(generaldata.strings[LEVELNAME],0,x,y,"editorname",false,2)
					MF_letterhide("editorname",1)
					--writetext(editor.strings[5],renamebuttonid,0,0,name,true)
				end
			end,
		structure =
		{
			{
				{{"closemenu"},},
				{{"test"},},
				{{"upload"},},
				{{"return"},},
				{{"theme"},},
				{{"delete"},},
			},
		}
	},
	musicload =
	{
		scrolling = 1,
		button = "MusicLoad",
		enter = 
			function(parent,name,buttonid)
				menudata_customscript.musiclist(parent,name,buttonid)
			end,
	},
	particlesload =
	{
		scrolling = 1,
		button = "ParticlesLoad",
		enter = 
			function(parent,name,buttonid)
				menudata_customscript.particleslist(parent,name,buttonid)
			end,
	},
	paletteload =
	{
		scrolling = 1,
		button = "PaletteLoad",
		enter = 
			function(parent,name,buttonid)
				menudata_customscript.palettelist(parent,name,buttonid)
			end,
	},
	levelsize =
	{
		button = "LevelSize",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 6.0
				
				local xoff = f_tilesize * 3
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
				
				x = f_tilesize * 5.0
				local bx = x + f_tilesize * 5.0
				y = y + f_tilesize * 3.5
				
				writetext(langtext("editor_levelsize_width") .. ":",0,x,y,name,false,2)
				
				y = y + f_tilesize
				
				createbutton("w-",bx - xoff,y,2,4,1,"-",name,3,2,buttonid)
				createbutton("w+",bx + xoff,y,2,4,1,"+",name,3,2,buttonid)
				
				local wcountid = MF_specialcreate("Editor_counter")
				local wcount = mmf.newObject(wcountid)
				wcount.x = bx + xoff + f_tilesize * 3
				wcount.y = y
				wcount.values[COUNTER_VALUE] = roomsizex
				wcount.strings[COUNTER_ID] = "levelw"
				
				y = y + f_tilesize * 2
				
				writetext(langtext("editor_levelsize_height") .. ":",0,x,y,name,false,2)
				
				y = y + f_tilesize
				
				createbutton("h-",bx - xoff,y,2,4,1,"-",name,3,2,buttonid)
				createbutton("h+",bx + xoff,y,2,4,1,"+",name,3,2,buttonid)
				
				local hcountid = MF_specialcreate("Editor_counter")
				local hcount = mmf.newObject(hcountid)
				hcount.x = bx + xoff + f_tilesize * 3
				hcount.y = y
				hcount.values[COUNTER_VALUE] = roomsizey
				hcount.strings[COUNTER_ID] = "levelh"
				
				y = y + f_tilesize * 2
				
				createbutton("apply",bx,y,2,10,1,langtext("editor_levelsize_apply"),name,3,2,buttonid)
				
				x = screenw * 0.5
				y = y + f_tilesize * 3
				
				writetext(langtext("editor_levelsize_quick") .. ":",0,x,y,name,true,2)
				
				y = y + f_tilesize
				
				createbutton("s148",x + f_tilesize * -14,y,2,3,1,"14x8",name,3,2,buttonid)
				createbutton("s1710",x + f_tilesize * -10,y,2,3,1,"17x10",name,3,2,buttonid)
				createbutton("s1616",x + f_tilesize * -6,y,2,3,1,"16x16",name,3,2,buttonid)
				createbutton("s2616",x + f_tilesize * -2,y,2,3,1,"26x16",name,3,2,buttonid)
				createbutton("s3018",x + f_tilesize * 2,y,2,3,1,"30x18",name,3,2,buttonid)
				createbutton("s2020",x + f_tilesize * 6,y,2,3,1,"20x20",name,3,2,buttonid)
				createbutton("s2620",x + f_tilesize * 10,y,2,3,1,"26x20",name,3,2,buttonid)
				createbutton("s3520",x + f_tilesize * 14,y,2,3,1,"35x20",name,3,2,buttonid)
				
				local frameid = MF_specialcreate("Editor_levelsizeframe")
				local frame = mmf.newObject(frameid)
				
				x = screenw * 0.5 + f_tilesize * 7.0
				y = screenh * 0.5 + f_tilesize * 1.0
				
				frame.x = x
				frame.y = y
				frame.layer = 2
				
				local c1,c2 = getuicolour("edge")
				MF_setcolour(frameid, c1, c2)
				
				local wlineid1 = MF_specialcreate("Editor_levelsize_w")
				local wline1 = mmf.newObject(wlineid1)
				wline1.layer = 2
				
				local wlineid2 = MF_specialcreate("Editor_levelsize_w")
				local wline2 = mmf.newObject(wlineid2)
				wline2.layer = 2
				wline2.values[1] = 1
				
				local hlineid1 = MF_specialcreate("Editor_levelsize_h")
				local hline1 = mmf.newObject(hlineid1)
				hline1.layer = 2
				
				local hlineid2 = MF_specialcreate("Editor_levelsize_h")
				local hline2 = mmf.newObject(hlineid2)
				hline2.layer = 2
				hline2.values[1] = 1
				
				MF_setcolour(wlineid1, 2, 2)
				MF_setcolour(wlineid2, 2, 2)
				MF_setcolour(hlineid1, 2, 2)
				MF_setcolour(hlineid2, 2, 2)
			end,
		leave = 
			function(parent,name)
				MF_delete("LevelSize")
				MF_removecounter("levelw")
				MF_removecounter("levelh")
			end,
		structure =
		{
			{
				{{"return"},},
				{{"w-"},{"w+"},},
				{{"h-"},{"h+"},},
				{{"apply"},},
				{{"s148"},{"s1710"},{"s1616"},{"s2616"},{"s3018"},{"s2020"},{"s2620"},{"s3520"},},
			},
		}
	},
	mapsetup =
	{
		button = "MapSetupButton",
		enter =
			function(parent,name,buttonid)			
				local x = screenw * 0.5
				local leftx = f_tilesize * 2
				local y = f_tilesize * 2
				
				createbutton("return",x,y,2,8,1,langtext("return"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				writetext(langtext("editor_map_leveltype") .. ":",0,x,y,name,true)
				
				y = y + f_tilesize
				
				createbutton("islevel",screenw * 0.25,y,2,8,1,langtext("editor_map_level"),name,3,2,buttonid)
				createbutton("ismap",screenw * 0.75,y,2,8,1,langtext("editor_map_map"),name,3,2,buttonid)
				
				local leveltype = editor.values[LEVELTYPE] + 1
				makeselection({"islevel","ismap"},leveltype)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_map_clearlimit") .. ":",0,x,y,name,true)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_map_clearlimit_hint"),0,x,y,name,true)
				
				y = y + f_tilesize
				
				createbutton("y--",x - f_tilesize * 4,y,2,1,1,"<<",name,3,2,buttonid)
				createbutton("y-",x - f_tilesize * 2,y,2,1,1,"<",name,3,2,buttonid)
				createbutton("y+",x + f_tilesize * 2,y,2,1,1,">",name,3,2,buttonid)
				createbutton("y++",x + f_tilesize * 4,y,2,1,1,">>",name,3,2,buttonid)
				
				local symbolid = MF_specialcreate("Editor_levelnum")
				local symbol = mmf.newObject(symbolid)
				symbol.values[TYPE] = editor.values[UNLOCKCOUNT]
				symbol.x = x
				symbol.y = y
				symbol.layer = 3
				
				y = y + f_tilesize * 2
				
				createbutton("seticons",x,y,2,16,1,langtext("editor_map_mapicon"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				writetext(langtext("editor_map_returnto") .. ":",0,x,y,name,true)
				
				y = y + f_tilesize
				
				createbutton("reset",x,y,2,16,1,langtext("editor_map_parentlevel"),name,3,2,buttonid)
				
				local customparent,cparentname = 1,langtext("editor_map_selectlevel")
				if (editor2.strings[CUSTOMPARENT] ~= "") then
					customparent,cparentname = 2,editor2.strings[CUSTOMPARENTNAME]
				end
				makeselection({"reset"},customparent)
				
				y = y + f_tilesize
				
				createbutton("changelevel",x,y,2,16,1,cparentname,name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"return"},},
				{{"islevel"},{"ismap"},},
				{{"y--"},{"y-"},{"y+"},{"y++"},},
				{{"seticons"},},
				{{"reset"},},
				{{"changelevel"},},
			},
		}
	},
	addlevel =
	{
		enter = 
			function(parent,name)
				local x = screenw * 0.5
				local leftx = f_tilesize * 6
				local y = f_tilesize * 1.5
				writetext(langtext("editor_level_leveltarget") .. ":",0,x,y,name,true)
				
				y = y + f_tilesize
				
				local unitid = editor.values[EDITTARGET]
				local unit = mmf.newObject(unitid)

				createbutton("changelevel",x,y,2,16,1,unit.strings[U_LEVELNAME],name,3,2,"AddLevel")
				
				y = y + f_tilesize * 3
				
				writetext(langtext("editor_level_iconcolour") .. ":",0,leftx,y,name,false)
				
				local paletteid = MF_specialcreate("Editor_colourselector")
				local palette = mmf.newObject(paletteid)
				
				palette.layer = 2
				palette.x = screenw * 0.55
				palette.y = screenh * 0.2
				
				local palettefile,paletteroot = MF_getpalettedata()
				local palettepath = getpath(paletteroot) .. "Palettes/" .. palettefile
				
				palette.strings[1] = palettepath
				
				MF_loadcolourselector(paletteid,palettepath)
				
				palette.scaleX = 24
				palette.scaleY = 24
				
				y = y + f_tilesize * 5
				
				writetext(langtext("editor_level_initialstate") .. ":",0,leftx - f_tilesize * 1.5,y,name,false)
				createbutton("s1",leftx + f_tilesize * 6,y,2,3.5,1,langtext("editor_level_initialstate_hidden"),name,3,2,"AddLevel")
				createbutton("s2",leftx + f_tilesize * 9.5,y,2,3.5,1,langtext("editor_level_initialstate_normal"),name,3,2,"AddLevel")
				createbutton("s3",leftx + f_tilesize * 13,y,2,3.5,1,langtext("editor_level_initialstate_opened"),name,3,2,"AddLevel")
				
				makeselection({"s1","s2","s3"},unit.values[COMPLETED] + 1)
				
				y = y + f_tilesize * 1
				
				writetext(langtext("editor_level_levelsymbol") .. ":",0,leftx - f_tilesize * 1.5,y,name,false)
				createbutton("l1",leftx + f_tilesize * 5.5,y,2,2.5,1,langtext("editor_level_levelsymbol_none"),name,3,2,"AddLevel")
				createbutton("l2",leftx + f_tilesize * 8.6,y,2,3.5,1,langtext("editor_level_levelsymbol_numbers"),name,3,2,"AddLevel")
				createbutton("l3",leftx + f_tilesize * 11.6,y,2,2.5,1,langtext("editor_level_levelsymbol_text"),name,3,2,"AddLevel")
				createbutton("l4",leftx + f_tilesize * 14.1,y,2,2.5,1,langtext("editor_level_levelsymbol_dots"),name,3,2,"AddLevel")
				createbutton("l5",leftx + f_tilesize * 16.4,y,2,2,1,"...",name,3,2,"AddLevel")
				
				local lselect = unit.values[VISUALSTYLE]
				if (lselect == -2) then
					lselect = -1
				elseif (lselect == -1) then
					lselect = 3
				end
				
				makeselection({"l1","l2","l3","l4","l5"},lselect + 2)
				
				y = y + f_tilesize * 1
				
				writetext(langtext("editor_level_levelsymbol_symbol") .. ":",0,leftx - f_tilesize * 1.5,y,name,false)
				createbutton("y--",leftx + f_tilesize * 5,y,2,1,1,"<<",name,3,2,"AddLevel")
				createbutton("y-",leftx + f_tilesize * 6,y,2,1,1,"<",name,3,2,"AddLevel")
				createbutton("y+",leftx + f_tilesize * 9,y,2,1,1,">",name,3,2,"AddLevel")
				createbutton("y++",leftx + f_tilesize * 10,y,2,1,1,">>",name,3,2,"AddLevel")
				
				local symbolid = MF_specialcreate("Editor_levelnum")
				local symbol = mmf.newObject(symbolid)
				symbol.x = leftx + f_tilesize * 7.5
				symbol.y = y
				symbol.layer = 3
				
				y = y + f_tilesize * 1
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,"AddLevel")
				
				y = y + f_tilesize * 2
				
				createbutton("removelevel",x,y,2,16,1,langtext("editor_level_remove"),name,3,2,"AddLevel")
			end,
		submenu_leave = 
			function(parent,name)
				MF_visible("AddLevel",0)
			end,
		submenu_return = 
			function(parent,name)
				MF_visible("AddLevel",1)
			end,
		leave = 
			function(parent,name)
				MF_delete("AddLevel")
			end,
	},
	levelselect =
	{
		scrolling = 1,
		leave = 
			function(parent,name)
				MF_delete("LevelButton")
				MF_letterclear("leveltext")
				
				local unitid = editor.values[EDITTARGET]
				local unit = mmf.newObject(unitid)
				updatebuttontext("changelevel",unit.strings[U_LEVELNAME],parent)
			end,
	},
	maplevelselect =
	{
		scrolling = 1,
		leave = 
			function(parent,name)
				MF_delete("LevelButton")
				MF_letterclear("leveltext")
				
				updatebuttontext("changelevel",editor2.strings[CUSTOMPARENTNAME],parent)
			end,
	},
	spriteselect =
	{
		scrolling = 1,
		leave = 
			function(parent,name)
				MF_delete("SpriteButton")
				MF_letterclear("leveltext")
			end,
	},
	iconselect =
	{
		scrolling = 1,
		submenu_leave = 
			function(parent,name)
				MF_visible("IconButton",0)
			end,
		submenu_return = 
			function(parent,name)
				MF_visible("IconButton",1)
			end,
		enter =
			function(parent,name)
				local x = roomsizex * f_tilesize * 0.5 * spritedata.values[TILEMULT]
				local y = f_tilesize * 1.5
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,"IconButton")
			end,
		leave = 
			function(parent,name)
				MF_delete("IconButton")
			end,
	},
	icons =
	{
		scrolling = 1,
		enter =
			function(parent,name)
				local x = roomsizex * f_tilesize * 0.5 * spritedata.values[TILEMULT]
				local y = f_tilesize * 1.5
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,"IconButton")
			end,
		leave = 
			function(parent,name)
				MF_delete("IconButton")
			end,
	},
	deleteconfirm =
	{
		button = "DeleteConfirm",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 3
				
				writetext(langtext("editor_delete_confirm"),0,x,y,name,true)
				
				y = y + f_tilesize * 2
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"yes"},},
				{{"no"},},
			},
		}
	},
	unsaved_confirm =
	{
		button = "UnsavedConfirm",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 3
				
				writetext(langtext("editor_unsaved_confirm"),0,x,y,name,true)
				
				y = y + f_tilesize * 2
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"no"},},
				{{"yes"},},
			},
		}
	},
	uploadlevel =
	{
		button = "UploadLevel",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 5
				
				writetext(langtext("editor_upload_name") .. ": $0,3" .. generaldata.strings[LEVELNAME],0,x,y,name,true)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_upload_author") .. ": $0,3" .. editor2.strings[AUTHOR],0,x,y,name,true)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_upload_difficulty") .. ": $0,3" .. editor2.strings[DIFFICULTY],0,x,y,name,true)
				
				y = y + f_tilesize * 2
				
				writetext(langtext("editor_upload_confirm"),0,x,y,name,true)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_upload_confirm_note"),0,x,y,name,true,nil,nil,{0,2})
				
				y = y + f_tilesize * 1.5
				
				--writetext(langtext("editor_upload_confirm_hint"),0,x,y,name,true,nil,nil,{0,2})
				
				y = y + f_tilesize
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"yes"},},
				{{"no"},},
			},
		}
	},
	upload_do =
	{
		button = "UploadDo",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5
				
				writetext(langtext("editor_upload_uploading"),0,x,y,name,true)
			end,
	},
	upload_done =
	{
		button = "UploadDone",
		enter = 
			function(parent,name,buttonid,extra)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 1
				
				local levelid,success = "",false
				
				if (extra ~= nil) and (#extra > 0) then
					levelid = extra[1]
					success = extra[2]
				end
				
				if success then
					writetext(langtext("editor_upload_done"),0,x,y,name,true)
					
					y = y + f_tilesize * 2
					
					writetext(levelid,0,x,y,name,true)
				else
					writetext(langtext("editor_upload_failed"),0,x,y,name,true)
					
					y = y + f_tilesize * 2
					
					writetext(levelid,0,x,y,name,true)
				end
				
				y = y + f_tilesize * 2
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"return"},},
			},
		}
	},
	setpath =
	{
		enter = 
			function(parent,name)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 2.5
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,"PathButton")
				
				y = y + f_tilesize * 1
				
				createbutton("hidden",x - f_tilesize * 4,y,2,8,1,langtext("editor_path_pathstate_hidden"),name,3,2,"PathButton")
				createbutton("visible",x + f_tilesize * 4,y,2,8,1,langtext("editor_path_pathstate_visible"),name,3,2,"PathButton")
				
				makeselection({"hidden","visible"},editor.values[PATHSTYLE] + 1)
				
				y = y + f_tilesize * 1
				
				writetext(langtext("editor_path_locked"),0,x,y,name,true)
				
				y = y + f_tilesize * 1
				
				createbutton("s1",x - f_tilesize * 9,y,2,6,1,langtext("no"),name,3,2,"PathButton")
				
				createbutton("s2",x - f_tilesize * 3,y,2,6,1,langtext("editor_path_locked_levels"),name,3,2,"PathButton")
				
				createbutton("s3",x + f_tilesize * 3,y,2,6,1,langtext("editor_path_locked_maps"),name,3,2,"PathButton")
				
				createbutton("s4",x + f_tilesize * 9,y,2,6,1,langtext("editor_path_locked_orbs"),name,3,2,"PathButton")
				
				makeselection({"s1","s2","s3","s4"},editor.values[PATHGATE] + 1)
				
				y = y + f_tilesize * 1
				
				local symbolid = MF_specialcreate("Editor_levelnum")
				local symbol = mmf.newObject(symbolid)
				symbol.x = x
				symbol.y = y
				symbol.layer = 3
				
				createbutton("y--",x - f_tilesize * 2,y,2,1,1,"<<",name,3,2,"PathButton")
				createbutton("y-",x - f_tilesize * 1,y,2,1,1,"<",name,3,2,"PathButton")
				createbutton("y+",x + f_tilesize * 1,y,2,1,1,">",name,3,2,"PathButton")
				createbutton("y++",x + f_tilesize * 2,y,2,1,1,">>",name,3,2,"PathButton")
			end,
		leave = 
			function(parent,name)
				MF_delete("PathButton")
			end,
	},
	objectedit =
	{
		button = "ObjectEditButton",
		enter = 
			function(parent,name,buttonid,unitname)
				local x = screenw * 0.5
				local y = f_tilesize * 1.5
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
				
				local extended = false
				local extended_ = tonumber(MF_read("settings","editor","mode")) or 0
				if (extended_ == 1) then
					extended = true
				end
				
				y = y + f_tilesize * 2
				
				local realname = unitreference[unitname]
				local currname = unitname
				local unittype = getactualdata(realname,"unittype")
				
				local unitid = MF_create(realname)
				local unit = mmf.newObject(unitid)
				
				unit.x = f_tilesize * 5
				unit.y = f_tilesize * 5
				unit.scaleX = 3
				unit.scaleY = 3
				unit.layer = 2
				editor.values[EDITTARGET] = unitid
				
				getmetadata(unit)
				if (changes[realname] ~= nil) then
					dochanges(unitid)
				end
				setcolour(unitid)
				
				if (extended == false) then
					y = y + f_tilesize * 1
				end
				
				writetext(currname .. " (" .. realname .. ") - " .. unittype,0,x,y,"objectinfo",true)
				
				x = screenw * 0.65
				y = y + f_tilesize * 1
				
				createbutton("sprite",x,y,2,12,1,langtext("editor_object_sprite"),name,3,2,buttonid)
				
				if extended then
					y = y + f_tilesize * 1
					
					createbutton("name",x,y,2,12,1,langtext("editor_object_name"),name,3,2,buttonid)
					
					y = y + f_tilesize * 1
					
					createbutton("type",x,y,2,12,1,langtext("editor_object_type"),name,3,2,buttonid)
				
					y = y + f_tilesize * 1
				else
					y = y + f_tilesize * 2
				end
				
				writetext("change colour:",0,x,y,name,true)
				
				y = y + f_tilesize * 1
				
				createbutton("colour",x - f_tilesize * 3.5,y,2,7,1,langtext("editor_object_colour_base"),name,3,2,buttonid)
				
				if (unittype == "text") then
					createbutton("acolour",x + f_tilesize * 3.5,y,2,7,1,langtext("editor_object_colour_active"),name,3,2,buttonid)
				end
				
				if extended then
					y = y + f_tilesize * 1
					
					writetext(langtext("editor_object_animation") .. ":",0,x,y,name,true)
					
					y = y + f_tilesize * 1
					
					local w = 4.5
					
					local bw = w * f_tilesize
					local bh = f_tilesize
					
					local ox = x - bw
					
					createbutton("a1",ox,y,2,w,1,langtext("editor_object_animation_none"),name,3,2,buttonid)
					createbutton("a2",ox + bw,y,2,w,1,langtext("editor_object_animation_dirs"),name,3,2,buttonid)
					createbutton("a3",ox + bw * 2,y,2,w,1,langtext("editor_object_animation_anim"),name,3,2,buttonid)
					createbutton("a4",ox,y + bh,2,w,1,langtext("editor_object_animation_animdirs"),name,3,2,buttonid)
					createbutton("a5",ox + bw,y + bh,2,w,1,langtext("editor_object_animation_character"),name,3,2,buttonid)
					createbutton("a6",ox + bw * 2,y + bh,2,w,1,langtext("editor_object_animation_tiled"),name,3,2,buttonid)
					
					local aselect_ = getactualdata(realname,"tiling")
					local aselect = aselect_
					if (aselect_ == 4) then
						aselect = 1
					elseif (aselect_ == 3) then
						aselect = 2
					elseif (aselect_ == 2) then
						aselect = 3
					elseif (aselect_ == 1) then
						aselect = 4
					end
					
					makeselection({"a1","a2","a3","a4","a5","a6"},aselect + 2)
					
					y = y + f_tilesize * 2
					
					writetext(langtext("editor_object_text_type") .. ":",0,x,y,name,true)
					
					y = y + f_tilesize * 1
					
					createbutton("w1",ox,y,2,w,1,"baba",name,3,2,buttonid)
					createbutton("w2",ox + bw,y,2,w,1,"is",name,3,2,buttonid)
					createbutton("w3",ox + bw * 2,y,2,w,1,"you",name,3,2,buttonid)
					
					local otype = getactualdata(realname,"type")
					makeselection({"w1","w2","w3"},otype + 1)
					
					y = y + f_tilesize * 1
					
					writetext(langtext("editor_object_text_manualtype") .. ":",0,x,y,name,true)
					
					y = y + f_tilesize * 1
					
					createbutton("-",x - f_tilesize * 1,y,2,1,1,"<",name,3,2,buttonid)
					createbutton("+",x + f_tilesize * 1,y,2,1,1,">",name,3,2,buttonid)
				
					local symbolid = MF_specialcreate("Editor_levelnum")
					local symbol = mmf.newObject(symbolid)
					symbol.x = x
					symbol.y = y
					symbol.layer = 3
					symbol.values[1] = 0
					
					symbol.values[TYPE] = otype
					
					y = y + f_tilesize * 1
				else
					y = y + f_tilesize * 2
				end
				
				writetext(langtext("editor_object_zlevel") .. ":",0,x,y,name,true)
				
				y = y + f_tilesize * 1
				
				createbutton("l-",x - f_tilesize * 1,y,2,1,1,"<",name,3,2,buttonid)
				createbutton("l+",x + f_tilesize * 1,y,2,1,1,">",name,3,2,buttonid)
				
				local symbolid2 = MF_specialcreate("Editor_levelnum")
				local symbol2 = mmf.newObject(symbolid2)
				symbol2.x = x
				symbol2.y = y
				symbol2.layer = 3
				symbol2.values[1] = -1
				
				symbol2.values[TYPE] = getactualdata(realname,"layer")
				
				y = y + f_tilesize * 1
				
				createbutton("reset",x,y,2,12,1,langtext("editor_object_reset"),name,3,2,buttonid)
			end,
		leave = 
			function(parent,name)
				MF_delete("ObjectEditButton")
				MF_letterclear("objectinfo",0)
			end,
		submenu_leave = 
			function(parent,name)
				MF_visible("ObjectEditButton",0)
				MF_letterclear("objectinfo",0)
			end,
		submenu_return = 
			function(parent,name)
				MF_visible("ObjectEditButton",1)
				
				local x = roomsizex * f_tilesize * 0.5 * spritedata.values[TILEMULT]
				local y = f_tilesize * 3.5
				
				local unitid = editor.values[EDITTARGET]
				local unit = mmf.newObject(unitid)
				
				local currname = unit.strings[UNITNAME]
				local realname = unit.className
				local unittype = unit.strings[UNITTYPE]
				
				writetext(currname .. " (" .. realname .. ") - " .. unittype,0,x,y,"objectinfo",true)
			end,
	},
	object_colour =
	{
		enter =
			function(parent,name)
				local x = screenw * 0.5
				local y = f_tilesize * 2
				
				writetext(langtext("editor_object_colour_select"),0,x,y,name,true)
				
				y = y + f_tilesize
				
				local paletteid = MF_specialcreate("Editor_colourselector")
				local palette = mmf.newObject(paletteid)
				
				palette.layer = 2
				palette.x = screenw * 0.5
				palette.y = screenh * 0.5 - f_tilesize * 2.5
				
				local palettefile,paletteroot = MF_getpalettedata()
				local palettepath = getpath(paletteroot) .. "Palettes/" .. palettefile
				
				palette.strings[1] = palettepath
				
				MF_loadcolourselector(paletteid,palettepath)
				
				palette.scaleX = 24
				palette.scaleY = 24
				
				createbutton("return",x,y,2,8,1,langtext("return"),name,3,2,"ColourButton")
				
				y = y + f_tilesize
			end,
		leave = 
			function(parent,name)
				MF_delete("ColourButton")
			end,
	},
	themes =
	{
		button = "ThemeEditor",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = f_tilesize * 1.5
				--writetext(langtext("editor_theme_edit") .. ":",0,x,y,name,true,1)
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("loadtheme",x,y,2,16,1,langtext("editor_theme_load"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("savetheme",x,y,2,16,1,langtext("editor_theme_save"),name,3,2,buttonid)
				
				y = y + f_tilesize
				
				createbutton("deletetheme",x,y,2,16,1,langtext("editor_theme_delete"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"return"},},
				{{"loadtheme"},},
				{{"savetheme"},},
				{{"deltheme"},},
			},
		}
	},
	themeload =
	{
		scrolling = 1,
		button = "ThemeLoad",
		enter = 
			function(parent,name,buttonid,extra)
				menudata_customscript.themelist(parent,name,buttonid,extra)
			end,
	},
	themeload_confirm =
	{
		button = "ThemeLoadConfirm",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 3
				
				writetext(langtext("editor_theme_load_confirm"),0,x,y,name,true,2,true)
				
				y = y + f_tilesize
				
				writetext(langtext("editor_theme_load_confirm_hint"),0,x,y,name,true,2,true)
				
				y = y + f_tilesize * 2
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"no"},},
				{{"yes"},},
			},
		}
	},
	themeload_confirm_newlevel =
	{
		button = "ThemeLoadConfirmNew",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 3
				
				writetext(langtext("editor_theme_load_confirm_newlevel"),0,x,y,name,true,2,true)
				
				y = y + f_tilesize * 2
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"no"},},
				{{"yes"},},
			},
		}
	},
	themedelete =
	{
		scrolling = 1,
		button = "ThemeDelete",
		enter = 
			function(parent,name,buttonid)
				menudata_customscript.themelist(parent,name,buttonid)
			end,
	},
	themedelete_confirm =
	{
		button = "EraseConfirm",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 3
				
				writetext(langtext("editor_theme_delete_confirm"),0,x,y,name,true,2,true)
				
				y = y + f_tilesize * 2
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"no"},},
				{{"yes"},},
			},
		}
	},
	themesave_confirm =
	{
		button = "EraseConfirm",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 3
				
				writetext(langtext("editor_theme_save_confirm"),0,x,y,name,true,2,true)
				
				y = y + f_tilesize * 2
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"no"},},
				{{"yes"},},
			},
		}
	},
	themeselect =
	{
		enter = 
			function(parent,name)
				local x = roomsizex * f_tilesize * 0.5 * spritedata.values[TILEMULT]
				local y = f_tilesize * 1.5
				writetext(langtext("editor_theme_use") .. ":",0,x,y,name,true,2)

				y = y + f_tilesize
				
				createbutton("return",x,y,2,16,1,langtext("editor_theme_return"),name,3,2,"ThemeButton")
			end,
		leave = 
			function(parent,name)
				MF_delete("ThemeButton")
				MF_delete("ThemeChoice")
				MF_letterclear("themes")
			end,
	},
	restartconfirm =
	{
		enter = 
			function(parent,name)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 3
				
				writetext(langtext("restart_confirm"),0,x,y,name,true,2,true)
				y = y + f_tilesize * 1
				writetext(langtext("restart_tip"),0,x,y,name,true,2,true,{1,4})
				
				y = y + f_tilesize * 2
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,"RestartConfirm")
				
				y = y + f_tilesize * 2
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,"RestartConfirm")
			end,
		leave = 
			function(parent,name)
				MF_delete("RestartConfirm")
			end,
	},
	playlevels =
	{
		scrolling = 1,
		button = "PlayLevels",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 2.5
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
				
				y = y + f_tilesize * 3
				
				local levels = MF_filelist("Data/Worlds/levels/","*.ld")
				local worlds = MF_dirlist("Data/Worlds/*")
				
				--writetext(langtext("customlevels") .. ":",0,x,y,name,true,1)
				
				local enablelevels = true
				local enableworlds = true
				
				if (#levels > 0) then
					enablelevels = false
				end
				
				for i,v in ipairs(worlds) do
					local worldfolder = string.sub(v, 2, string.len(v) - 1)
					
					if (worldfolder ~= "levels") then
						enableworlds = false
					end
				end
				
				createbutton("customlevels_play_singular",x,y,2,16,2,langtext("customlevels_play_singular"),name,3,2,buttonid,enablelevels)
				
				y = y + f_tilesize * 2
				
				createbutton("customlevels_play_get",x,y,2,16,2,langtext("customlevels_play_get"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("customlevels_play_pack",x,y,2,16,2,langtext("customlevels_play_pack"),name,3,2,buttonid,enableworlds)
			end,
		structure =
		{
			{
				{{"return"},},
				{{"customlevels_play_singular"},},
				{{"customlevels_play_get"},},
				{{"customlevels_play_pack"},},
			},
		}
	},
	playlevels_pack =
	{
		scrolling = 1,
		button = "PlayLevels_pack",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = f_tilesize * 1.5
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				writetext(langtext("customlevels") .. ":",0,x,y,name,true,1)
				
				local worlds = MF_dirlist("Data/Worlds/*")
				
				editor2.values[MENU_YDIM] = #worlds - 1
				
				local actual_i = 1
				
				for i,v in ipairs(worlds) do
					local worldfolder = string.sub(v, 2, string.len(v) - 1)
					
					if (worldfolder ~= "levels") then
						y = y + f_tilesize * 3
						
						MF_setfile("world","Data/Worlds/" .. worldfolder .. "/world_data.txt")
						
						local worldfolder_ = tostring(actual_i) .. "," .. worldfolder
						
						local worldname = string.lower(MF_read("world","general","name"))
						local bid = createbutton(worldfolder_,x,y,1,16,3,worldname,name,3,2,buttonid)
						
						MF_alert(worldfolder_)
						
						local imagefile = "icon"
						MF_thumbnail("Worlds/" .. worldfolder .. "/",imagefile,actual_i-1,0,0,bid,0,3,0-f_tilesize * 6.5,0,buttonid,"")
						
						actual_i = actual_i + 1
					end
				end
				
				MF_loop("scrollarea", 1)
			end,
		leave = 
			function(parent,name)
				MF_clearthumbnails("")
			end,
	},
	slots =
	{
		button = "SlotMenu",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = 5 * f_tilesize
				
				local world = generaldata.strings[BASEWORLD]
				
				writetext(langtext("slots_select") .. ":",0,x,y,name,true,2,true)

				y = y + f_tilesize * 2.5
				
				for saveslot=1,3 do
					local savefile = tostring(saveslot - 1) .. "ba.ba"
					MF_setfile("save",savefile)
					prizes = tonumber(MF_read("save",world .. "_prize","total")) or 0
					clears = tonumber(MF_read("save",world .. "_clears","total")) or 0
					bonus = tonumber(MF_read("save",world .. "_bonus","total")) or 0
					timer = tonumber(MF_read("save",world,"time")) or 0
					win = tonumber(MF_read("save",world,"end")) or 0
					done = tonumber(MF_read("save",world,"done")) or 0
				
					minutes = string.sub("00" .. tostring(math.floor(timer / 60) % 60), -2)
					hours = tostring(math.floor(timer / 3600))
				
					slotname = langtext("slot") .. " " .. tostring(saveslot)
				
					if (prizes > 0) then
						slotname = ""
						
						if (win == 1) then
							if (generaldata4.values[CUSTOMFONT] == 0) then
								slotname = slotname .. "{ "
							else
								slotname = slotname .. "😀 "
							end
						end
						
						if (done == 1) then
							if (generaldata4.values[CUSTOMFONT] == 0) then
								slotname = slotname .. "} "
							else
								slotname = slotname .. "😃 "
							end
						end
						
						if (win == 1) or (done == 1) then
							slotname = slotname .. "  "
						end
						
						if (generaldata4.values[CUSTOMFONT] == 0) then
							slotname = slotname .. hours .. ":" .. minutes .. "£  " .. tostring(prizes) .. "@  " .. tostring(clears) .. "¤"
						else
							slotname = slotname .. hours .. ":" .. minutes .. "💀  " .. tostring(prizes) .. "😈  " .. tostring(clears) .. "😠"
						end
					end
				
					if (bonus > 0) then
						slotname = slotname .. "  (+" .. tostring(bonus) .. ")"
					end
					
					local buttoncode = "s" .. tostring(saveslot)
					createbutton(buttoncode,x,y,2,16,2,slotname,name,3,2,buttonid)
					
					y = y + f_tilesize * 2
				end
				
				MF_setfile("save","ba.ba")
				
				y = y + f_tilesize * 0.5
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("erase",x,y,2,16,1,langtext("slots_erase"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"s1"},},
				{{"s2"},},
				{{"s3"},},
				{{"return"},},
				{{"erase"},},
			},
		}
	},
	slots_erase =
	{
		button = "SlotEraseMenu",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = 5 * f_tilesize
				
				local world = generaldata.strings[BASEWORLD]
				
				writetext(langtext("erase_select") .. ":",0,x,y,name,true,2,true)

				y = y + f_tilesize * 2.5
				
				for saveslot=1,3 do
					local savefile = tostring(saveslot - 1) .. "ba.ba"
					MF_setfile("save",savefile)
					
					local prizes = tonumber(MF_read("save",world .. "_prize","total")) or 0
					local clears = tonumber(MF_read("save",world .. "_clears","total")) or 0
					local bonus = tonumber(MF_read("save",world .. "_bonus","total")) or 0
					local timer = tonumber(MF_read("save",world,"time")) or 0
					local win = tonumber(MF_read("save",world,"end")) or 0
					local done = tonumber(MF_read("save",world,"done")) or 0
					
					local minutes = string.sub("00" .. tostring(math.floor(timer / 60) % 60), -2)
					local hours = tostring(math.floor(timer / 3600))
					
					local slotname = langtext("slot") .. " " .. tostring(saveslot)
					
					if (prizes > 0) then
						slotname = ""
						
						if (win == 1) then
							if (generaldata4.values[CUSTOMFONT] == 0) then
								slotname = slotname .. "{ "
							else
								slotname = slotname .. "😀 "
							end
						end
						
						if (done == 1) then
							if (generaldata4.values[CUSTOMFONT] == 0) then
								slotname = slotname .. "} "
							else
								slotname = slotname .. "😃 "
							end
						end
						
						if (win == 1) or (done == 1) then
							slotname = slotname .. "  "
						end
						
						if (generaldata4.values[CUSTOMFONT] == 0) then
							slotname = slotname .. hours .. ":" .. minutes .. "£  " .. tostring(prizes) .. "@  " .. tostring(clears) .. "¤"
						else
							slotname = slotname .. hours .. ":" .. minutes .. "💀  " .. tostring(prizes) .. "😈  " .. tostring(clears) .. "😠"
						end
					end
					
					if (bonus > 0) then
						slotname = slotname .. "  (+" .. tostring(bonus) .. ")"
					end
					
					local buttoncode = tostring(saveslot - 1) .. "ba"
					createbutton(buttoncode,x,y,2,16,2,slotname,name,2,2,buttonid)
					
					y = y + f_tilesize * 2
				end
				
				MF_setfile("save","ba.ba")
				
				y = y + f_tilesize * 0.5
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"0ba"},},
				{{"1ba"},},
				{{"2ba"},},
				{{"return"},},
			},
		}
	},
	eraseconfirm =
	{
		button = "EraseConfirm",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 3
				
				writetext(langtext("erase_confirm"),0,x,y,name,true,2,true)
				y = y + f_tilesize * 1
				writetext(langtext("erase_tip"),0,x,y,name,true,2,true,{1,4})
				
				y = y + f_tilesize * 2
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"no"},},
				{{"yes"},},
			},
		}
	},
	watchintro =
	{
		button = "IntroConfirm",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 4
				
				writetext(langtext("intro_confirm"),0,x,y,name,true,2,true)
				
				y = y + f_tilesize * 2
				
				createbutton("yes",x,y,2,16,1,langtext("yes"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("no",x,y,2,16,1,langtext("no"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				createbutton("cancel",x,y,2,16,1,langtext("cancel"),name,3,2,buttonid)
			end,
		structure =
		{
			{
				{{"yes"},},
				{{"no"},},
				{{"cancel"},},
			},
		}
	},
	languages =
	{
		button = "LanguageMenu",
		enter = 
			function(parent,name,buttonid)
				local x = screenw * 0.5
				local y = screenh * 0.5 - f_tilesize * 6
				
				writetext(langtext("lang_setup") .. ":",0,x,y,name,true,2,true)
				
				local langs = MF_filelist("Data/Languages/","*.txt")
				
				y = y + f_tilesize * 2
				
				local selection = 0
				local options = {}
				
				x = x - f_tilesize * 6
				local x_ = 0
				
				local dynamic_structure = {{}}
				local dynamic_structure_y = 1
				local dynamic_structure_x = dynamic_structure[dynamic_structure_y]
				
				for c,d in ipairs(langs) do
					MF_setfile("lang",d)
					
					local buttonname = string.sub(d, 1, string.len(d) - 4)
					local langname = MF_read("lang","general","name")
					
					if (generaldata4.values[CUSTOMFONT] == 0) then
						langname = string.lower(langname)
					end
					
					createbutton(buttonname,x + x_ * 12 * f_tilesize,y,2,10,1,langname,name,3,2,buttonid)
					
					if (generaldata.strings[LANG] == string.sub(buttonname, 6)) then
						selection = c
					end
					
					table.insert(options, buttonname)
					
					table.insert(dynamic_structure_x, {buttonname})
					
					x_ = x_ + 1
					if (x_ > 1) and (c < #langs) then
						x_ = 0
						y = y + f_tilesize
						
						table.insert(dynamic_structure, {})
						dynamic_structure_y = dynamic_structure_y + 1
						dynamic_structure_x = dynamic_structure[dynamic_structure_y]
					end
				end
				
				makeselection(options,selection)
				
				MF_setfile("lang","lang_" .. generaldata.strings[LANG] .. ".txt")
				
				x = screenw * 0.5
				y = y + f_tilesize
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
				
				editor2.values[MENU_XDIM] = 1
				editor2.values[MENU_YDIM] = math.floor(#langs / 2) + 1
				
				table.insert(dynamic_structure, {{"return"}})
				buildmenustructure(dynamic_structure)
			end,
	},
	enterlevel_multiple =
	{
		button = "MultipleLevels",
		enter = 
			function(parent,name,buttonid,extra)
				local x = screenw * 0.5
				local y = f_tilesize * 4.5
				
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
				
				y = y + f_tilesize * 2
				
				writetext(langtext("enterlevel_multiple") .. ":",0,x,y,name,true,2)
				
				y = y + f_tilesize * 1
				
				editor2.values[MENU_YDIM] = #extra
				
				for i,v in ipairs(extra) do
					y = y + f_tilesize * 1
					
					local levelunit = v[1]
					local levelname = v[2]
					createbutton(tostring(i) .. "," .. fixed_to_str(levelunit),x,y,2,16,1,levelname,name,3,2,buttonid)
				end
			end,
	},
	objlist =
	{
		button = "EditorObjectList",
		enter = 
			function(parent,name,buttonid,extra)
				editor2.values[OBJLISTTYPE] = 0
				editor_objects_build(nil,nil)
				
				local x = 2
				local y = 2
				
				createbutton("return",6 * f_tilesize,y * f_tilesize,2,6,1,langtext("return"),name,3,2,buttonid)
				
				y = 3
				
				createbutton("search_edit",7 * f_tilesize,y * f_tilesize,2,8,1,langtext("editor_objectlist_search_edit"),name,3,2,buttonid)
				createbutton("search_remove",15 * f_tilesize,y * f_tilesize,2,8,1,langtext("editor_objectlist_search_remove"),name,3,2,buttonid)
				createbutton("search_tags",22 * f_tilesize,y * f_tilesize,2,6,1,langtext("editor_objectlist_tags"),name,3,2,buttonid)
				
				y = 4
				
				local subline = ""
				
				if (string.len(objlistdata.search) > 0) then
					subline = langtext("editor_objectlist_result") .. " '" .. objlistdata.search .. "'"
					
					if (#objlistdata.tags > 0) then
						subline = subline .. ", "
					end
				end
				
				if (#objlistdata.tags > 0) then
					if (#objlistdata.tags == 1) then
						subline = subline .. langtext("editor_objectlist_tag") .. ": "
					else
						subline = subline .. langtext("editor_objectlist_tags") .. ": "
					end
					
					for i,v in ipairs(objlistdata.tags) do
						subline = subline .. v
						
						if (i < #objlistdata.tags) then
							subline = subline .. ", "
						end
					end
				end
				
				if (string.len(subline) == 0) then
					subline = langtext("editor_objectlist_search_none")
				end
				
				writetext(subline,0,3 * f_tilesize,y * f_tilesize,name,false,2)
				
				y = 3.5
				
				local xdim = (screenw - f_tilesize * 4) / (f_tilesize * 2)
				
				local pagesize = 60
				local page = extra or 0
				local maxpage = math.ceil(#editor_objects / pagesize)
				local minobj = page * pagesize + 1
				local maxobj = math.min((page + 1) * pagesize, #editor_objects)
				
				for i=minobj,maxobj do
					local id = editor_objects[i]["objlistid"]
					local v = editor_objlist[id]
					local bid = createbutton_objlist(tostring(id),x * (f_tilesize * 2),y * (f_tilesize * 2),name,3,2,buttonid)
					--local bid = createbutton(tostring(i),x * (f_tilesize * 2),y * (f_tilesize * 2),2,2,2,"<empty>",name,3,2,buttonid)
					
					local imagefile = v.sprite or v.name
					local c = v.colour_active or v.colour
					local c1 = c[1] or 0
					local c2 = c[2] or 3
					imagefile = imagefile .. "_0_1"
					MF_thumbnail("Sprites/",imagefile,i-1,0,0,bid,c1,c2,0,0,buttonid,"")
					
					x = x + 1
					
					if (x > xdim + 1) then
						x = 2
						y = y + 1
					end
				end
				
				local cannot_scroll_left = true
				local cannot_scroll_right = true
				
				if (page > 0) then
					cannot_scroll_left = false
				end
				
				if (page < maxpage - 1) then
					cannot_scroll_right = false
				end
				
				if (maxpage > 1) then
					createbutton("scroll_left",screenw * 0.5 - f_tilesize * 4,screenh - f_tilesize * 2,2,2,2,"◄",name,3,2,buttonid,cannot_scroll_left)
					createbutton("scroll_right",screenw * 0.5 + f_tilesize * 4,screenh - f_tilesize * 2,2,2,2,"►",name,3,2,buttonid,cannot_scroll_right)
				
					writetext(langtext("editor_objectlist_page") .. ": " .. tostring(page + 1) .. "/" .. tostring(maxpage),0,screenw * 0.5,screenh - f_tilesize * 2,name,true,2)
				end
			end,
		leave = 
			function(parent,name)
				MF_clearthumbnails("EditorObjectList")
			end,
	},
	objlist_update =
	{
		button = "EditorObjectList_update",
		enter = 
			function(parent,name,buttonid,extra)
				MF_clearthumbnails("")
			end,
	},
	objlist_tags =
	{
		button = "EditorObjectList_tags",
		enter = 
			function(parent,name,buttonid)
				local x = 2
				local y = 2
				
				createbutton("return",6 * f_tilesize,2 * f_tilesize,2,8,1,langtext("return"),name,3,2,buttonid)
				
				y = 3
				
				writetext(langtext("editor_objectlist_tags_select"),0,x * f_tilesize,y * f_tilesize,name,false,2)
				
				x = 0.75
				y = 4
				
				local xdim = (screenw - f_tilesize * 16) / (f_tilesize * 8)
				
				local tagdata = objlistdata.tags
				if (editor2.values[OBJLISTTYPE] == 1) then
					tagdata = objlistdata.tags_currobjlist
				end
				
				for i,tag in ipairs(objlistdata.alltags) do
					if (tag ~= "special") then
						local tag_ = langtext("tag_" .. tag)
						if (tag_ == "not found") then
							tag_ = tag
						end
						
						local used = 0
						for a,b in ipairs(tagdata) do
							if (b == tag) then
								used = 1
							end
						end
						
						s,c = gettoggle(used)
						
						local bid = createbutton("tag," .. tag,x * f_tilesize * 8,y * f_tilesize,2,8,1,tag_,name,3,2,buttonid,nil,s)
						
						x = x + 1
						
						if (x >= xdim + 2) then
							x = 0.75
							y = y + 1
						end
					end
				end
			end,
	},
	currobjlist =
	{
		button = "CurrentObjectList",
		enter = 
			function(parent,name,buttonid,extra)
				editor2.values[OBJLISTTYPE] = 1
				editor_objects_build(nil,nil)
				
				local total = #editor_objects
				local total_ = #editor_currobjlist
				
				local ymult = 1.5
				
				local dynamic_structure = {}
				
				if (total_ > 1) then
					createbutton("search_edit",4.5 * f_tilesize,ymult * f_tilesize,2,6,1,langtext("editor_objectlist_search_edit"),name,3,2,buttonid)
					createbutton("search_remove",10.5 * f_tilesize,ymult * f_tilesize,2,6,1,langtext("editor_objectlist_search_remove"),name,3,2,buttonid)
					createbutton("search_tags",16.5 * f_tilesize,ymult * f_tilesize,2,6,1,langtext("editor_objectlist_tags_select"),name,3,2,buttonid)
					
					table.insert(dynamic_structure, {{"search_edit"},{"search_remove"},{"search_tags"},{"nothing"}})
					
					ymult = ymult + 1
				else
					table.insert(dynamic_structure, {{"nothing"}})
				end
				
				local atlimit = false
				if (total_ >= 150) then
					atlimit = true
				end
				createbutton("add",4.5 * f_tilesize,ymult * f_tilesize,2,6,1,langtext("editor_objectlist_add"),name,3,2,buttonid,atlimit,nil,langtext("tooltip_objectlist_add",true))
				
				local dynamic_structure_row = {{"add"}}
				
				if (total_ > 0) then
					createbutton("remove",10.5 * f_tilesize,ymult * f_tilesize,2,6,1,langtext("editor_objectlist_remove"),name,3,2,buttonid)
					createbutton("editobject",16.5 * f_tilesize,ymult * f_tilesize,2,6,1,langtext("editor_objectlist_editobject"),name,3,2,buttonid)
					
					table.insert(dynamic_structure_row, {"remove"})
					table.insert(dynamic_structure_row, {"editobject"})
				end
				
				table.insert(dynamic_structure_row, {"dopairs"})
				
				table.insert(dynamic_structure, dynamic_structure_row)
				
				local pair_option_names = {"editor_objectlist_pairs_no", "editor_objectlist_pairs_yes"}
				local pair_option = editor2.values[DOPAIRS] + 1
				
				createbutton("nothing",24.5 * f_tilesize,ymult * f_tilesize - f_tilesize,2,8,1,langtext("editor_objectlist_nothing"),name,3,2,buttonid)
				createbutton("dopairs",24.5 * f_tilesize,ymult * f_tilesize,2,8,1,langtext(pair_option_names[pair_option]),name,3,2,buttonid)
				createbutton("editor_return",23.5 * f_tilesize,ymult * f_tilesize + f_tilesize,2,6,1,langtext("return"),name,3,2,buttonid)
				
				table.insert(dynamic_structure, {{"editor_return"}})
				
				ymult = ymult + 1
				
				local subline = ""
				
				if (string.len(objlistdata.search) > 0) then
					subline = langtext("editor_objectlist_result") .. " '" .. objlistdata.search .. "'"
					
					if (#objlistdata.tags > 0) then
						subline = subline .. ", "
					end
				end
				
				if (string.len(subline) == 0) then
					subline = langtext("editor_objectlist_search_none")
				end
				
				writetext(subline,0,1.5 * f_tilesize,ymult * f_tilesize,name,false,2)
				
				if (total > 0) then
					local x = 1
					local y = 1
					
					local xmaxdim = 15
					local ymaxdim = 10
					
					local ydim = math.floor(math.sqrt(total))
					local xdim = math.floor(total / ydim)
					
					ydim = math.min(ymaxdim, ydim)
					local maxtotal = xdim * ydim
					
					while (total > maxtotal) do
						xdim = xdim + 1
						maxtotal = xdim * ydim
					end
					
					local yoff = ymult * f_tilesize
					local xoff = f_tilesize * 0.5 + 6
					local tsize = 36
					
					MF_setobjlisttopleft(tsize + xoff,tsize + yoff)
					
					for i=1,total do
						local iddata = editor_objects[i]
						local id = iddata.objlistid
						local oid = iddata.databaseid
						
						local gx = x
						local gy = y
						
						local obj = editor_currobjlist[oid]
						
						if (editor2.values[DOPAIRS] == 1) then
							if (obj.grid_overlap ~= nil) then
								local gridpos = obj.grid_overlap
								gx = gridpos[1] + 1
								gy = gridpos[2] + 1
							end
						elseif (editor2.values[DOPAIRS] == 0) then
							if (obj.grid_full ~= nil) then
								local gridpos = obj.grid_full
								gx = gridpos[1] + 1
								gy = gridpos[2] + 1
							end
						end
						
						local v = editor_objlist[id]
						local name = v.name
						
						local objword = editor2.values[OBJECTWORDSWAP]
						local objwords = {["object"] = 0, ["text"] = 1}
						local ut = objwords[v.unittype] or 0
						local valid = true
						
						if (editor2.values[DOPAIRS] == 1) and ((v.unpaired == nil) or (v.unpaired == false)) and ((obj.pair ~= nil) and (obj.pair ~= 0)) then
							if (v.type == 0) and (ut ~= objword) then
								valid = false
							end
						end
						
						if valid then
							local bid = createbutton_objlist(tostring(i) .. "," .. name,gx * tsize + xoff,gy * tsize + yoff,name,3,2,buttonid,2)
							
							local imagefile = getactualdata_objlist(obj.object, "sprite")
							local ut = getactualdata_objlist(obj.object, "unittype")
							local c = {}
							
							if (ut == "object") then
								c = getactualdata_objlist(obj.object, "colour")
							elseif (ut == "text") then
								c = getactualdata_objlist(obj.object, "active")
							end
							
							local c1 = c[1] or 0
							local c2 = c[2] or 3
							
							imagefile = imagefile .. "_0_1"
							MF_thumbnail("Sprites/",imagefile,i-1,0,0,bid,c1,c2,0,0,buttonid,obj.object)
							
							--local backid = MF_create("Editor_background")
							
							x = x + 1
							
							if (x > xdim) then
								x = 1
								y = y + 1
							end
						end
					end
				end
				
				local dir = editor.values[EDITORDIR]
				
				local dir_x = screenw - f_tilesize * 5
				local dir_y = f_tilesize * 4.6
				
				createbutton("dir_right",dir_x + f_tilesize * 2.5,dir_y,2,2.5,2.5,"►",name,3,2,buttonid)
				createbutton("dir_up",dir_x,dir_y - f_tilesize * 2.5,2,2.5,2.5,"▲",name,3,2,buttonid)
				createbutton("dir_left",dir_x - f_tilesize * 2.5,dir_y,2,2.5,2.5,"◄",name,3,2,buttonid)
				createbutton("dir_down",dir_x,dir_y + f_tilesize * 2.5,2,2.5,2.5,"▼",name,3,2,buttonid)
				
				makeselection({"dir_right","dir_up","dir_left","dir_down"},dir + 1)
				
				dir_y = f_tilesize * 5 + f_tilesize * 5
				
				createbutton("tool_normal",dir_x,dir_y,2,8,1,langtext("editor_tool_normal"),name,3,2,buttonid)
				createbutton("tool_line",dir_x,dir_y + f_tilesize * 1,2,8,1,langtext("editor_tool_line"),name,3,2,buttonid)
				createbutton("tool_rectangle",dir_x,dir_y + f_tilesize * 2,2,8,1,langtext("editor_tool_rectangle"),name,3,2,buttonid)
				createbutton("tool_fillrectangle",dir_x,dir_y + f_tilesize * 3,2,8,1,langtext("editor_tool_fillrectangle"),name,3,2,buttonid)
				createbutton("tool_fill",dir_x,dir_y + f_tilesize * 4,2,8,1,langtext("editor_tool_fill"),name,3,2,buttonid)
				
				local selected_tool = editor2.values[EDITORTOOL]
				makeselection({"tool_normal","tool_line","tool_rectangle","tool_fillrectangle","tool_fill"},selected_tool + 1)
				
				if (editor2.values[EXTENDEDMODE] == 1) then
					dir_y = dir_y + f_tilesize * 4 + f_tilesize * 2
					
					createbutton("brush_normal",dir_x,dir_y,2,8,1,langtext("editor_brush_normal"),name,3,2,buttonid)
					createbutton("brush_level",dir_x,dir_y + f_tilesize * 1,2,8,1,langtext("editor_brush_level"),name,3,2,buttonid)
					createbutton("brush_path",dir_x - f_tilesize * 0.5,dir_y + f_tilesize * 2,2,7,1,langtext("editor_brush_path"),name,3,2,buttonid)
					createbutton("brush_special",dir_x,dir_y + f_tilesize * 3,2,8,1,langtext("editor_brush_special"),name,3,2,buttonid)
					
					createbutton("brush_pathsetup",dir_x + f_tilesize * 3.5,dir_y + f_tilesize * 2,2,1,1,"💩",name,3,2,buttonid)
					
					selected_tool = editor.values[STATE]
					makeselection({"brush_normal","brush_level","_brush_cursor","brush_path","brush_special"},selected_tool + 1)
				end
				
				buildmenustructure(dynamic_structure)
			end,
		leave = 
			function(parent,name)
				MF_clearthumbnails("CurrentObjectList")
			end,
	},
	currobjlist_update =
	{
		button = "EditorObjectList_update",
		enter = 
			function(parent,name,buttonid,extra)
				MF_clearthumbnails("")
			end,
	},
	currobjlist_update_objects =
	{
		button = "EditorObjectList_update_objects",
		enter = 
			function(parent,name,buttonid,extra)
				local total = #editor_objects
				
				for i=1,total do
					local iddata = editor_objects[i]
					local id = iddata.objlistid
					local oid = iddata.databaseid
					
					local data = editor_objlist[id]
					local obj = editor_currobjlist[oid]
					
					local name = data.name
					
					local objword = editor2.values[OBJECTWORDSWAP]
					local objwords = {["object"] = 0, ["text"] = 1}
					local ut = objwords[data.unittype] or 0
					
					if (obj.pair ~= nil) and (obj.pair ~= 0) and (ut ~= objword) then
						local buttonfunc = tostring(i) .. "," .. name
						local objbuttonid = MF_getobjbuttonid(buttonfunc)
						
						if (objbuttonid > 0) then
							MF_clearthumbnail_withowner(objbuttonid)
							local objbutton = mmf.newObject(objbuttonid)
							
							local pairobjid = obj.pair
							local pairobj = editor_currobjlist[pairobjid]
							local v = editor_objlist[pairobj.id]
							
							local tempid = 0
							for a,b in ipairs(editor_objects) do
								if (b.databaseid == obj.pair) then
									tempid = a
									break
								end
							end
							
							--MF_alert(name .. ", " .. tostring(tempid))
							
							MF_alert(obj.name .. ", " .. pairobj.name)
							
							if (tempid > 0) then
								local newbuttonfunc = tostring(tempid) .. "," .. pairobj.name
								objbutton.strings[BUTTONFUNC] = newbuttonfunc
								
								local imagefile = getactualdata_objlist(pairobj.object, "sprite")
								local c = {}
								local ut = getactualdata_objlist(pairobj.object, "unittype")
								
								if (ut == "object") then
									c = getactualdata_objlist(pairobj.object, "colour")
								elseif (ut == "text") then
									c = getactualdata_objlist(pairobj.object, "active")
								end
								
								local c1 = c[1] or 0
								local c2 = c[2] or 3
								
								imagefile = imagefile .. "_0_1"
								MF_thumbnail("Sprites/",imagefile,i-1,0,0,objbuttonid,c1,c2,0,0,"CurrentObjectList",pairobj.object)
							end
						end
					end
				end
				
				closemenu()
			end,
	},
}

menudata_customscript =
{
	worldlist =
		function(parent,name,buttonid)
			local x = screenw * 0.5
			local y = f_tilesize * 1.5
			
			createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
			
			y = y + f_tilesize * 2
			
			writetext(langtext("editor_editworld") .. ":",0,x,y,name,true,2)
			
			y = y + f_tilesize * 2
			
			local world = generaldata.strings[WORLD]
			
			local opts = MF_dirlist("Data/Worlds/*")
			
			if (#opts <= 1) then
				writetext(langtext("editor_editworld_none"),0,x,y,name,true,2)
			end
			
			local dynamic_structure = {{{"return"}}}
			local curr_dynamic_structure = {}
			
			x = x - f_tilesize * 5
			local x_ = 0
			local y_ = 0
			
			table.insert(dynamic_structure, {})
			curr_dynamic_structure = dynamic_structure[#dynamic_structure]
			
			for i,v_ in ipairs(opts) do
				local v = string.sub(v_, 2, string.len(v_) - 1)
				if (v ~= "levels") then
					MF_setfile("world","Data/Worlds/" .. v .. "/world_data.txt")
					
					local optbutton = v
					local optname = string.lower(MF_read("world","general","name")) or ""
					if (#optname == 0) then
						optname = "unnamed"
					end
					
					createbutton(optbutton,x + x_ * f_tilesize * 10,y + y_ * f_tilesize,2,8,1,optname,name,3,2,buttonid)
					
					table.insert(curr_dynamic_structure, {optbutton})
					
					x_ = x_ + 1
					
					if (x_ > 1) and (i < #opts) then
						x_ = 0
						y_ = y_ + 1
						
						table.insert(dynamic_structure, {})
						curr_dynamic_structure = dynamic_structure[#dynamic_structure]
					end
				end
			end
			
			MF_setfile("world","Data/Worlds/" .. generaldata.strings[WORLD] .. "/world_data.txt")
			
			editor2.values[MENU_XPOS] = 0
			editor2.values[MENU_YPOS] = 0
			editor2.values[MENU_XDIM] = 1
			editor2.values[MENU_YDIM] = math.floor(#opts / 2) + 1
			
			x = screenw * 0.5
			y = y + f_tilesize * 2
			
			createbutton("make a new world",x,y + y_ * f_tilesize,2,16,1,langtext("editor_newworld"),name,3,2,buttonid)
			table.insert(dynamic_structure, {{"make a new world"}})
			
			buildmenustructure(dynamic_structure)
		end,
	themelist =
		function(parent,name,buttonid,extra)
			local x = screenw * 0.5
			local y = f_tilesize * 1.5
			
			local menutype = extra or false
			
			if (menutype == false) then
				createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
			else
				createbutton("return",x,y,2,16,1,langtext("editor_theme_done"),name,3,2,buttonid)
			end
			
			y = y + f_tilesize * 2
			
			if (buttonid == "ThemeLoad") then
				writetext(langtext("editor_theme_themeload") .. ":",0,x,y,name,true,2)
			elseif (buttonid == "ThemeDelete") then
				writetext(langtext("editor_theme_themedelete") .. ":",0,x,y,name,true,2)
			end
			
			y = y + f_tilesize * 2
			
			local world = generaldata.strings[WORLD]
			
			local themes = MF_filelist("Data/Themes/","*.txt")
			local worldthemes = MF_filelist("Data/Worlds/" .. world .. "/Themes/","*.txt")
			
			if ((#themes == 0) and (#worldthemes == 0)) or ((buttonid == "ThemeDelete") and (#worldthemes == 0)) then
				writetext(langtext("editor_theme_none"),0,x,y,name,true,2)
			end
			
			local dynamic_structure = {{{"return"}}}
			local curr_dynamic_structure = {}
			
			x = x - f_tilesize * 5
			local x_ = 0
			local y_ = 0
			
			table.insert(dynamic_structure, {})
			curr_dynamic_structure = dynamic_structure[#dynamic_structure]
			
			if (buttonid ~= "ThemeDelete") then
				for i,v in ipairs(themes) do
					local themefile = v
					MF_setfile("level","Data/Themes/" .. v)
					
					local themename = MF_read("level","general","name")
					local themebutton = v .. ",0"
					createbutton(themebutton,x + x_ * f_tilesize * 10,y + y_ * f_tilesize,2,8,1,themename,name,3,2,buttonid)
					
					table.insert(curr_dynamic_structure, {themebutton})
					
					x_ = x_ + 1
					
					if (x_ > 1) and ((#worldthemes > 0) or (i < #themes)) then
						x_ = 0
						y_ = y_ + 1
						
						table.insert(dynamic_structure, {})
						curr_dynamic_structure = dynamic_structure[#dynamic_structure]
					end
				end
			end
			
			for i,v in ipairs(worldthemes) do
				local themefile = v
				MF_setfile("level","Data/Worlds/" .. world .. "/Themes/" .. v)
				
				local themename = MF_read("level","general","name")
				local themebutton = v .. ",1"
				createbutton(themebutton,x + x_ * f_tilesize * 10,y + y_ * f_tilesize,2,8,1,themename,name,3,2,buttonid)
				
				table.insert(curr_dynamic_structure, {themebutton})
				
				x_ = x_ + 1
				
				if (x_ > 1) and (i < #worldthemes) then
					x_ = 0
					y_ = y_ + 1
					
					table.insert(dynamic_structure, {})
					curr_dynamic_structure = dynamic_structure[#dynamic_structure]
				end
			end
			
			local level = generaldata.strings[CURRLEVEL]
			MF_setfile("level","Data/Worlds/" .. world .. "/" .. level .. ".ld")
			
			editor2.values[MENU_XPOS] = 0
			editor2.values[MENU_YPOS] = 0
			editor2.values[MENU_XDIM] = 1
			editor2.values[MENU_YDIM] = math.floor((#themes + #worldthemes) / 2) + 1
			
			buildmenustructure(dynamic_structure)
		end,
	palettelist =
		function(parent,name,buttonid)
			local x = screenw * 0.5
			local y = f_tilesize * 1.5
			
			createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
			
			y = y + f_tilesize * 2
			
			writetext(langtext("editor_palette_select") .. ":",0,x,y,name,true,2)
			
			y = y + f_tilesize * 2
			
			local world = generaldata.strings[WORLD]
			
			local opts = MF_filelist("Data/Palettes/","*.png")
			local worldopts = MF_filelist("Data/Worlds/" .. world .. "/Palettes/","*.png")
			
			if (#opts == 0) and (#worldopts == 0) then
				writetext(langtext("editor_palette_none"),0,x,y,name,true,2)
			end
			
			local paletteid = MF_specialcreate("Editor_colourselector")
			local palette = mmf.newObject(paletteid)
			
			palette.layer = 2
			palette.x = screenw * 0.5 + f_tilesize * 10
			palette.y = screenh * 0.5 - f_tilesize * 3
			palette.scaleX = 24
			palette.scaleY = 24
			palette.visible = false
			
			local dynamic_structure = {{{"return"}}}
			local curr_dynamic_structure = {}
			
			x = x - f_tilesize * 10
			local x_ = 0
			local y_ = 0
			
			table.insert(dynamic_structure, {})
			curr_dynamic_structure = dynamic_structure[#dynamic_structure]
			
			for i,v in ipairs(opts) do
				local optbutton = v .. ",0"
				local optname = string.sub(v, 1, string.len(v) - 4)
				createbutton(optbutton,x + x_ * f_tilesize * 10,y + y_ * f_tilesize,2,8,1,optname,name,3,2,buttonid)
				
				table.insert(curr_dynamic_structure, {optbutton})
				
				x_ = x_ + 1
				
				if (x_ > 1) and ((#worldopts > 0) or (i < #opts)) then
					x_ = 0
					y_ = y_ + 1
					
					table.insert(dynamic_structure, {})
					curr_dynamic_structure = dynamic_structure[#dynamic_structure]
				end
			end
			
			for i,v in ipairs(worldopts) do
				local optbutton = v .. ",0"
				local optname = string.sub(v, 1, string.len(v) - 4)
				createbutton(optbutton,x + x_ * f_tilesize * 10,y + y_ * f_tilesize,2,8,1,optname,name,3,2,buttonid)
				
				table.insert(curr_dynamic_structure, {optbutton})
				
				x_ = x_ + 1
				
				if (x_ > 1) and (i < #worldopts) then
					x_ = 0
					y_ = y_ + 1
					
					table.insert(dynamic_structure, {})
					curr_dynamic_structure = dynamic_structure[#dynamic_structure]
				end
			end
			
			editor2.values[MENU_XPOS] = 0
			editor2.values[MENU_YPOS] = 0
			editor2.values[MENU_XDIM] = 1
			editor2.values[MENU_YDIM] = math.floor((#opts + #worldopts) / 2) + 1
			
			buildmenustructure(dynamic_structure)
		end,
	musiclist =
		function(parent,name,buttonid)
			local x = screenw * 0.5
			local y = f_tilesize * 1.5
			
			createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
			
			y = y + f_tilesize * 2
			
			writetext(langtext("editor_music_select") .. ":",0,x,y,name,true,2)
			
			y = y + f_tilesize * 2
			
			local world = generaldata.strings[WORLD]
			
			local opts = MF_filelist("Data/Music/","*.ogg")
			local worldopts = MF_filelist("Data/Worlds/" .. world .. "/Music/","*.ogg")
			
			if (#opts == 0) and (#worldopts == 0) then
				writetext(langtext("editor_music_none"),0,x,y,name,true,2)
			end
			
			local dynamic_structure = {{{"return"}}}
			local curr_dynamic_structure = {}
			
			x = x - f_tilesize * 5
			local x_ = 0
			local y_ = 0
			
			table.insert(dynamic_structure, {})
			curr_dynamic_structure = dynamic_structure[#dynamic_structure]
			
			for i,v in ipairs(opts) do
				local optbutton = v .. ",0"
				local optname = string.sub(v, 1, string.len(v) - 4)
				createbutton(optbutton,x + x_ * f_tilesize * 10,y + y_ * f_tilesize,2,8,1,optname,name,3,2,buttonid)
				
				table.insert(curr_dynamic_structure, {optbutton})
				
				x_ = x_ + 1
				
				if (x_ > 1) and ((#worldopts > 0) or (i < #opts)) then
					x_ = 0
					y_ = y_ + 1
					
					table.insert(dynamic_structure, {})
					curr_dynamic_structure = dynamic_structure[#dynamic_structure]
				end
			end
			
			for i,v in ipairs(worldopts) do
				local optbutton = v .. ",0"
				local optname = string.sub(v, 1, string.len(v) - 4)
				createbutton(optbutton,x + x_ * f_tilesize * 10,y + y_ * f_tilesize,2,8,1,optname,name,3,2,buttonid)
				
				table.insert(curr_dynamic_structure, {optbutton})
				
				x_ = x_ + 1
				
				if (x_ > 1) and (i < #worldopts) then
					x_ = 0
					y_ = y_ + 1
					
					table.insert(dynamic_structure, {})
					curr_dynamic_structure = dynamic_structure[#dynamic_structure]
				end
			end
			
			editor2.values[MENU_XPOS] = 0
			editor2.values[MENU_YPOS] = 0
			editor2.values[MENU_XDIM] = 1
			editor2.values[MENU_YDIM] = math.floor((#opts + #worldopts) / 2) + 1
			
			buildmenustructure(dynamic_structure)
		end,
	particleslist =
		function(parent,name,buttonid)
			local x = screenw * 0.5
			local y = f_tilesize * 1.5
			
			createbutton("return",x,y,2,16,1,langtext("return"),name,3,2,buttonid)
			
			y = y + f_tilesize * 2
			
			writetext(langtext("editor_particles_select") .. ":",0,x,y,name,true,2)
			
			y = y + f_tilesize * 2
			
			local world = generaldata.strings[WORLD]
			local opts = particletypes
			
			local count = 0
			for i,v in pairs(opts) do
				count = count + 1
			end

			if (count == 0) then
				writetext(langtext("editor_particles_none"),0,x,y,name,true,2)
			end
			
			local dynamic_structure = {{{"return"}}}
			local curr_dynamic_structure = {}
			
			x = x - f_tilesize * 5
			local x_ = 0
			local y_ = 0
			
			table.insert(dynamic_structure, {})
			curr_dynamic_structure = dynamic_structure[#dynamic_structure]
			
			local count_ = 0
			for i,v in pairs(opts) do
				count_ = count_ + 1
				createbutton(i,x + x_ * f_tilesize * 10,y + y_ * f_tilesize,2,8,1,i,name,3,2,buttonid)
				
				table.insert(curr_dynamic_structure, {optbutton})
				
				x_ = x_ + 1
				
				if (x_ > 1) and (count_ < count) then
					x_ = 0
					y_ = y_ + 1
					
					table.insert(dynamic_structure, {})
					curr_dynamic_structure = dynamic_structure[#dynamic_structure]
				end
			end
			
			editor2.values[MENU_XPOS] = 0
			editor2.values[MENU_YPOS] = 0
			editor2.values[MENU_XDIM] = 1
			editor2.values[MENU_YDIM] = math.floor(count / 2) + 1
			
			buildmenustructure(dynamic_structure)
		end,
}