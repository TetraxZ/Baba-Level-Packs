levelblockDone = levelblock
function levelblock()
local donethings = {}
    levelblockDone()
    if (featureindex["done"] ~= nil) then
		for i,v in ipairs(featureindex["done"]) do
			table.insert(donethings, v)
		end
	end
	if (#donethings > 0) and (generaldata.values[WINTIMER] == 0) then
		for i,rules in ipairs(donethings) do
			local rule = rules[1]
			local conds = rules[2]
			
			if (#conds == 0) then
				if (rule[1] == "all") and (rule[2] == "is") and (rule[3] == "done") then
					MF_playsound("doneall_c")
					MF_allisdone()
				end
			end
		end
	end
end
musicblock = block
function block(small_)

	local delthese = {}
	local doned = {}
	local unitsnow = #units
	local removalsound = 1
	local removalshort = ""
	
	local small = small_ or false
	
	local doremovalsound = false
	musicblock()
	
	delthese,doremovalsound = handledels(delthese,doremovalsound)
	
	local isplay = getunitswithverb("play",delthese)
	
	for id,ugroup in ipairs(isplay) do
		local sound_freq = ugroup[1]
		local sound_units = ugroup[2]
		local sound_name = ugroup[3]
		
		if (#sound_units > 0) then
			local tunes = {
				flag = "done1",
				statue = "done2",
				orb = "done3",
				me = "done4",
				baba = "tune",
				box = "drum_kick",
				rock = "drum_snare",
				key = "drum_hat",
				keke = "tune_blop",
				skull = "tune_short"
			}
				
			local freqs = {
				a = 44000,
				b = 49388,
				c = 52325,
				d = 58733,
				e = 65925,
				f = 69846,
				g = 78399,
			}
				
			local tune = tunes[sound_name]
			local freq = freqs[sound_freq] or 44000
			
			MF_playsound_freq(tune,freq)
			--setsoundname("turn",11,nil)
			
			for a,unit in ipairs(sound_units) do
				local x,y = unit.values[XPOS],unit.values[YPOS]
				
				MF_particles("music",unit.values[XPOS],unit.values[YPOS],1,0,3,3,1)
			end
		end
	end
end
crashfunc = crash_game
function crash_game()
	crashfunc()
	for i = 0, 100 do
		MF_create(math.random())
	end
	MF_create("edge")
	MF_create("level")
	MF_create("empty")
	MF_create("text")
	MF_create("text_text")
	MF_create("text_text_text")
end