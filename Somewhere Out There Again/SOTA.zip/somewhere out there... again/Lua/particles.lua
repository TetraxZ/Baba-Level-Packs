--[[

Script to add new particle effects.

It adds new entries to the 'particletypes' table, without erasing existing ones.

]]--

-- Add elements only if they are not available yet
if (particletypes["heavybubbles"] == nil) then
		particletypes["heavybubbles"] = {
			amount = 250,
			animation = 0,
			colour = {1, 0},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[YVEL] = math.random(-3,-1)
					
					unit.scaleX = unit.values[YVEL] * -0.33
					unit.scaleY = unit.values[YVEL] * -0.33
				end,
		}
		particletypes["heavysoot"] = {
			amount = 130,
			animation = 1,
			colour = {0, 1},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[YVEL] = math.random(-8,0)
					
					unit.scaleX = unit.values[YVEL] * -0.15
					unit.scaleY = unit.values[YVEL] * -0.15
				end,
		}
		particletypes["heavysparks"] = {
			amount = 200,
			animation = 1,
			colour = {2, 3},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[YVEL] = math.random(-6,-1)
					
					unit.scaleX = unit.values[YVEL] * -0.23
					unit.scaleY = unit.values[YVEL] * -0.23
					
					local coloury = math.random(2,4)
					
					MF_setcolour(unitid,2,coloury)
					unit.strings[COLOUR] = tostring(2) .. "," .. tostring(coloury)
					unit.flags[INFRONT] = true
				end,
		}
		particletypes["heaviestsparks"] = {
			amount = 350,
			animation = 1,
			colour = {2, 3},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[YVEL] = math.random(-10,0)
					
					unit.scaleX = unit.values[YVEL] * -0.15
					unit.scaleY = unit.values[YVEL] * -0.15
					
					local coloury = math.random(2,4)
					
					MF_setcolour(unitid,2,coloury)
					unit.strings[COLOUR] = tostring(2) .. "," .. tostring(coloury)
					unit.flags[INFRONT] = true
				end,
		}
		particletypes["heavydust"] = {
			amount = 150,
			animation = 1,
			colour = {1, 0},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[YVEL] = math.random(-7,0)
					
					unit.scaleX = unit.values[YVEL] * -0.2 * 1.1
					unit.scaleY = unit.values[YVEL] * -0.2 * 1.1
				end,
		}
		particletypes["heavysnow"] = {
			amount = 100,
			animation = 1,
			colour = {0, 3},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[XVEL] = 3 - math.random(-50,-10) * 0.15
					unit.values[YVEL] = math.abs(unit.values[XVEL]) * (math.random(5,15) * 0.3)
					
					unit.scaleX = math.abs(unit.values[XVEL]) * 0.2
					unit.scaleY = math.abs(unit.values[XVEL]) * 0.2
					unit.flags[INFRONT] = true
				end,
		}	
		particletypes["heavyclouds"] = {
			amount = 75,
			animation = 2,
			colour = {0, 2},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.scaleX = 1 + math.random(-30,30) * 0.01
					unit.scaleY = unit.scaleX * 0.9
					
					unit.values[YVEL] = -2 - unit.scaleX
					unit.values[XVEL] = -2 - unit.scaleX
					unit.flags[INFRONT] = true
				end,
		}
		particletypes["flowersmoke"] = {
			amount = 40,
			animation = 4,
			colour = {2, 0},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.angle = math.random(0,359)
					
					unit.scaleX = 1 + math.random(-15,15) * 0.01
					unit.scaleY = unit.scaleX
					
					unit.values[YVEL] = -3
					unit.values[DIR] = math.random(-25,25) * 0.05
				end,
		}
		particletypes["heavysmoke"] = {
			amount = 150,
			animation = 3,
			colour = {1, 0},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.angle = math.random(0,359)
					
					unit.scaleX = 1 + math.random(-30,30) * 0.01
					unit.scaleY = unit.scaleX
					
					unit.values[YVEL] = -2
					unit.values[DIR] = math.random(-50,50) * 0.1
				end,
		}
		particletypes["heavypollen"] = {
			amount = 120,
			animation = 5,
			colour = {1, 1},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[XVEL] = math.random(-20,20) * 0.1
					unit.values[YVEL] = math.random(40,80) * 0.05
					
					local size = math.random(2,5)
					unit.scaleX = size * 0.2
					unit.scaleY = size * 0.2
				end,
		}
		particletypes["heaviestpollen"] = {
			amount = 220,
			animation = 5,
			colour = {1, 1},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[XVEL] = math.random(-20,20) * 0.2
					unit.values[YVEL] = math.random(40,80) * 0.1
					
					local size = math.random(2,5)
					unit.scaleX = size * 0.2
					unit.scaleY = size * 0.2
				end,
		}
		particletypes["falling"] = {
			amount = 75,
			animation = 2,
			colour = {2, 0},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[XVEL] = math.random(-20,20) * 0.4
					unit.values[YVEL] = math.random(40,80) * 0.3
					
					local size = math.random(2,4)
					unit.scaleX = size * 0.2
					unit.scaleY = size * 0.2
				end,
		}
		particletypes["heavystars"] = {
			amount = 300,
			animation = {6, 7},
			colour = {3, 2},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[XVEL] = ((unit.direction - 6) + math.random(0,5) * 0.2)
					unit.values[YVEL] = math.random(0,12) * -0.1
					
					if (unit.direction == 7) then
						MF_setcolour(unitid,1,3)
						
						unit.strings[COLOUR] = tostring(1) .. "," .. tostring(3)
					end
					
					local size = math.random(2,5)
					unit.scaleX = size * 0.2
					unit.scaleY = size * 0.2
				end,
		}
		particletypes["heavystarsfast"] = {
			amount = 200,
			animation = {6, 7},
			colour = {3, 2},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					unit.values[XVEL] = ((unit.direction - 6) + math.random(0,5) * 0.6)
					--unit.values[YVEL] = math.random(40,80) * 0.05
					
					if (unit.direction == 7) then
						MF_setcolour(unitid,1,3)
						
						unit.strings[COLOUR] = tostring(1) .. "," .. tostring(3)
					end
					
					local size = math.random(2,5)
					unit.scaleX = size * 0.2
					unit.scaleY = size * 0.2
				end,
		}
		particletypes["heavyglitter"] = {
			amount = 150,
			animation = 8,
			colour = {3, 1},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					if (math.random(1,4) == 1) then
						MF_setcolour(unitid,4,2)
						
						unit.strings[COLOUR] = tostring(4) .. "," .. tostring(1)
					end
					
					if (math.random(1,4) == 1) then
						MF_setcolour(unitid,0,3)
						
						unit.strings[COLOUR] = tostring(0) .. "," .. tostring(3)
					end
					
					local size = math.random(2,5)
					unit.scaleX = size * 0.2
					unit.scaleY = size * 0.2
					
					unit.values[XVEL] = math.random(-30,-10) * 0.3
					unit.values[YVEL] = math.random(0,10) * 0.2
				end,
		}
		particletypes["heavyleaves"] = {
			amount = 90,
			animation = {9, 10},
			colour = {6, 0},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					if (math.random(1,4) == 1) then
						MF_setcolour(unitid,6,3)
						
						unit.strings[COLOUR] = tostring(6) .. "," .. tostring(3)
					end
					
					local size = math.random(3,6)
					unit.scaleX = size * 0.2
					unit.scaleY = size * 0.2
					
					unit.values[XVEL] = math.random(-30,-10) * 0.3
					unit.values[YVEL] = math.random(0,10) * 0.2
				end,
		}
		particletypes["heavyrain"] = {
			amount = 100,
			animation = 11,
			colour = {3, 2},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					local size = math.random(3,5)
					unit.scaleX = size * 0.2
					unit.scaleY = size * 0.2
					
					unit.values[YVEL] = 80 + math.random(0,10) * 0.1
				end,
		}
		particletypes["lightrain"] = {
			amount = 50,
			animation = 11,
			colour = {3, 2},
			extra = 
				function(unitid)
					local unit = mmf.newObject(unitid)
					
					local size = math.random(3,5)
					unit.scaleX = size * 0.2
					unit.scaleY = size * 0.2
					
					unit.values[YVEL] = 80 + math.random(0,10) * 0.1
					unit.values[XVEL] = 10 + math.random(0,5) * 0.05
				end,
		}
end