Just unzip into the Baba Is You folder (it'll put the world in Worlds, the music into Music)
Pack will not work on Old-Editor branch, so make sure you are in the current public branch or beta branch.
The editor_menudata.lua file will add the Custom Levels button to the menu