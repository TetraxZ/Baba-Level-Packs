Put the world into the steamapps\common\Baba Is You\Data\Worlds folder
Pack will not work on Old-Editor branch, so make sure you are in the current public branch or beta branchs.