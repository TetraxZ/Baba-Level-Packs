local mod = {}

-- options.lua to edit
mod.enabled = {}
mod.tile = {}
mod.macros = {}

mod.tilecount = 0

-- Calls when a world is first loaded
function mod.load(dir)
	-- Load mod code
	loadscript(dir .. "blocks")
	loadscript(dir .. "rules")
	loadscript(dir .. "ending")
	loadscript(dir .. "effects")
	loadscript(dir .. "tools")
	loadscript(dir .. "values")
	--loadscript(dir .. "editor_menudata")
end

-- Calls when another world is loaded while this mod is active
function mod.unload(dir)
	-- Unload mod code
	loadscript("Data/blocks")
	loadscript("Data/rules")
	loadscript("Data/ending")
	loadscript("Data/effects")
	loadscript("Data/tools")
	loadscript("Data/values")
	--loadscript("Data/Editor/editor_menudata")
end
return mod