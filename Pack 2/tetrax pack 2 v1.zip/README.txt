If you do not have the modloader installed:

Extract modloader.lua to the base game folder (where Baba Is You.exe is), and add this line:

require("modloader")

to the BOTTOM of Data/load.lua